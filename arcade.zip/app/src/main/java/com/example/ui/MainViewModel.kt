package com.example.ui

import android.app.Application
import android.content.Context
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AchievementEntity
import com.example.data.ChallengeEntity
import com.example.data.GameEndSummary
import com.example.data.GameProgressEntity
import com.example.data.LumoDatabase
import com.example.data.LumoRepository
import com.example.data.UserProfileEntity
import com.example.games.GameRegistry
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("lumo_prefs", Context.MODE_PRIVATE)
    private val database = LumoDatabase.getDatabase(application)
    private val repository = LumoRepository(database)

    private val _language = mutableStateOf(AppLanguage.ARABIC)
    val language: State<AppLanguage> = _language

    val profileState: StateFlow<UserProfileEntity?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allGamesProgressState: StateFlow<List<GameProgressEntity>> = repository.allGamesProgress
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val challengesState: StateFlow<List<ChallengeEntity>> = repository.challenges
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val achievementsState: StateFlow<List<AchievementEntity>> = repository.achievements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
        prefs.edit().putString("app_lang", lang.code).apply()
    }

    fun finishOnboarding() {
        viewModelScope.launch {
            repository.completeOnboarding()
        }
    }

    fun completeAuthGuest() {
        viewModelScope.launch {
            repository.completeOnboarding()
        }
    }

    fun onGameFinished(gameId: String, score: Int, timeMs: Long, level: Int): GameEndSummary {
        val gameDef = GameRegistry.getGameById(gameId)
        return runBlocking {
            repository.recordGameFinished(
                gameId = gameId,
                gameName = gameDef.title,
                category = gameDef.category,
                score = score,
                timeMs = timeMs,
                levelPlayed = level
            )
        }
    }

    fun claimChallenge(challengeId: String) {
        viewModelScope.launch {
            repository.claimChallengeReward(challengeId)
        }
    }

    fun claimAchievement(achievementId: String) {
        viewModelScope.launch {
            repository.claimAchievementReward(achievementId)
        }
    }

    fun updateUsername(name: String) {
        viewModelScope.launch {
            val currentAvatar = profileState.value?.avatarIndex ?: 0
            repository.updateProfile(name, currentAvatar)
        }
    }

    fun toggleSound(enabled: Boolean) {
        viewModelScope.launch {
            val currentHaptic = profileState.value?.hapticEnabled ?: true
            repository.updateSettings(soundEnabled = enabled, hapticEnabled = currentHaptic)
        }
    }

    fun toggleHaptics(enabled: Boolean) {
        viewModelScope.launch {
            val currentSound = profileState.value?.soundEnabled ?: true
            repository.updateSettings(soundEnabled = currentSound, hapticEnabled = enabled)
        }
    }

    fun resetAllData() {
        viewModelScope.launch {
            repository.resetAllData()
        }
    }
}
