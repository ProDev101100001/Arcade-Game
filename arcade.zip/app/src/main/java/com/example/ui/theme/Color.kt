package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Lumo Modern Arcade Light Canvas & Surfaces
val LumoBackground = Color(0xFFF7F8FC)
val LumoSurface = Color(0xFFFFFFFF)
val LumoSurfaceSubtle = Color(0xFFF1F4F9)
val LumoSurfaceVariant = Color(0xFFEDF2F7)
val LumoBorder = Color(0xFFE2E8F0)
val LumoBorderSubtle = Color(0xFFEDF2F7)

// Brand Color - Vibrant, Deep Royal Indigo (#1800AD)
val LumoPrimary = Color(0xFF1800AD)
val LumoPrimaryDark = Color(0xFF0E006B)
val LumoPrimaryLight = Color(0xFF3B25E6)
val LumoPrimarySurface = Color(0xFFEDEDFD)
val LumoPrimaryLilac = Color(0xFFC7D2FE)
val LumoPrimaryGlow = Color(0x331800AD)

// Text Hierarchy - Slate High-Contrast Professional
val LumoTextPrimary = Color(0xFF0F172A)
val LumoTextSecondary = Color(0xFF475569)
val LumoTextTertiary = Color(0xFF94A3B8)
val LumoTextInverse = Color(0xFFFFFFFF)

// Game Accent System - Energetic Arcade Identity
val LumoCoral = Color(0xFFFF3366)       // Reflex / Quick Tap
val LumoCoralLight = Color(0xFFFFF0F3)
val LumoCoralDark = Color(0xFFE11D48)

val LumoIris = Color(0xFF6366F1)        // Memory / Memory Match
val LumoIrisLight = Color(0xFFEEF2FF)
val LumoIrisDark = Color(0xFF4F46E5)

val LumoEmerald = Color(0xFF10B981)     // Focus / Odd One Out
val LumoEmeraldLight = Color(0xFFECFDF5)
val LumoEmeraldDark = Color(0xFF059669)

val LumoAmber = Color(0xFFF59E0B)       // Trophy / Daily / XP
val LumoAmberLight = Color(0xFFFFFBEB)
val LumoAmberDark = Color(0xFFD97706)

val LumoCyan = Color(0xFF06B6D4)
val LumoRose = Color(0xFFF43F5E)

// Semantic State Colors
val LumoSuccess = Color(0xFF10B981)
val LumoError = Color(0xFFEF4444)
val LumoWarning = Color(0xFFF59E0B)
