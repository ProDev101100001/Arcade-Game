package com.example.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.LayoutDirection

enum class AppLanguage(val code: String, val displayName: String, val layoutDirection: LayoutDirection) {
    ARABIC("ar", "العربية", LayoutDirection.Rtl)
}

class Strings(val lang: AppLanguage = AppLanguage.ARABIC) {
    // App Brand & General
    val appName = "أركيد"
    val tagline = "ألعاب سريعة. متعة فورية."
    val continueAsGuest = "المتابعة كضيف"
    val signInWithGoogle = "المتابعة مع Google"
    val signInWithApple = "المتابعة مع Apple"
    val signInWithEmail = "تسجيل الدخول بالبريد"
    val welcome = "مرحباً بك في أركيد"
    val welcomeSub = "تحديات مصغرة يومية لسرعة البديهة والتركيز"
    val getStarted = "ابدأ الآن"
    val or = "أو"
    val termsPrivacy = "بالمتابعة، أنت توافق على الشروط وسياسة الخصوصية"

    // Navigation Tabs
    val tabHome = "الرئيسية"
    val tabGames = "الألعاب"
    val tabChallenges = "التحديات"
    val tabProfile = "حسابي"

    // Home Screen
    val greetingHello = "مرحباً،"
    val readyForQuickRound = "جاهز لجولة سريعة؟"
    val suggestedForYou = "لعبة مقترحة لك"
    val playNow = "العب الآن"
    val dailyChallenge = "تحدي اليوم"
    val featuredGame = "اللعبة المميزة"
    val todayGames = "ألعاب اليوم"
    val exploreGames = "مكتبة الألعاب"
    val viewAll = "عرض الكل"
    val level = "المستوى"
    val xp = "نقطة"
    val streak = "أيام"
    val start = "ابدأ"
    val continuePlaying = "تابع اللعب"

    // Games Screen & Collections
    val gameLibraryTitle = "الألعاب"
    val gameLibrarySubtitle = "اختر لعبتك"
    val chooseNextGame = "اختر لعبتك"
    val searchPlaceholder = "ابحث عن لعبة..."
    val catAll = "الكل"
    val catReflex = "سريع"
    val catMemory = "ذاكرة"
    val catFocus = "تركيز"
    val catNew = "جديد"
    val bestScore = "أفضل نتيجة"
    val plays = "مرات اللعب"
    val play = "العب"
    val lockedGame = "يفتح في المستوى"
    val newBadge = "جديد"
    val featuredArcade = "ألعاب مميزة"
    val newArcade = "جديد الأركيد"
    val featuredCollections = "مجموعات الألعاب"
    val colQuickGames = "ألعاب سريعة"
    val colQuickGamesSub = "اختبر سرعتك ورد فعلك"
    val colMemoryGames = "تحديات الذاكرة"
    val colMemoryGamesSub = "مرّن ذاكرتك وقوة التركيز"
    val colFocusGames = "ألعاب التركيز"
    val colFocusGamesSub = "قوة الملاحظة والدقة الفورية"
    val colRecentGames = "تابع اللعب"
    val colRecentGamesSub = "ألعابك الأخيرة"
    val colNewGames = "الألعاب الجديدة"
    val noGamesFound = "لا توجد ألعاب مطابقة للبحث"

    // Game Titles & Descriptions
    val quickTapTitle = "الضغطات السريعة"
    val quickTapDesc = "اضغط على الأهداف بأقصى سرعة وتجنب الفخاخ"
    val memoryMatchTitle = "مطابقة الذاكرة"
    val memoryMatchDesc = "احفظ مواقع الرموز واكشف الأزواج المتطابقة"
    val oddOneOutTitle = "العنصر المختلف"
    val oddOneOutDesc = "اعثر على الرمز أو اللون المختلف بدقة وسرعة"

    // Game Specific Feedback
    val trapHit = "فخ! -150"
    val perfectHit = "سريع جداً! +150"
    val goldenHit = "هدف ذهبي! +250"
    val goodHit = "+100"
    val normalHit = "+60"
    val streakBonus = "سلسلة متتالية!"
    val reactionSpeed = "سرعة الرد"
    val targetCount = "الأهداف"

    // Additional Arcade Game Catalog
    val colorChallengeTitle = "تحدي الألوان"
    val colorChallengeSub = "اختر اللون الصحيح"
    val obstacleDodgeTitle = "تجنب العقبات"
    val obstacleDodgeSub = "انجُ أطول وقت ممكن"
    val memorySequenceTitle = "تسلسل الذاكرة"
    val reactionTimeTitle = "ردة الفعل"
    val movingTargetTitle = "الهدف المتحرك"
    val speedMathTitle = "الرياضيات السريعة"
    val numberOrderTitle = "ترتيب الأرقام"

    // Challenges Screen
    val challengesTitle = "التحديات"
    val challengesSub = "جاهز للتحدي؟"
    val todayChallenge = "تحدي اليوم"
    val completedGamesCount = "أكمل 3 ألعاب"
    val completedOf = "مكتملة"
    val startChallenge = "ابدأ التحدي"
    val speedChallenge = "تحدي السرعة"
    val memoryChallenge = "تحدي الذاكرة"
    val focusChallenge = "تحدي التركيز"
    val oneGame = "لعبة واحدة"
    val claimReward = "استلام المكافأة"
    val claimed = "تم الاستلام"
    val inProgress = "قيد التقدم"
    val completed = "مكتمل"

    // Settings & Profile Sections
    val playerProfile = "الملف والإعدادات"
    val sectionAccount = "الحساب"
    val sectionAppearance = "المظهر"
    val sectionGameplay = "أسلوب اللعب والمؤثرات"
    val sectionNotifications = "الإشعارات"
    val sectionAbout = "حول التطبيق"
    val editName = "تعديل الاسم"
    val guestAccount = "حساب ضيف"
    val logOut = "تسجيل الخروج"
    val confirmLogout = "هل تريد تسجيل الخروج والعودة لشاشة البداية؟"
    val dailyReminders = "تذكير التحديات اليومية"
    val stats = "الإحصائيات"
    val totalGamesPlayed = "الألعاب الملعوبة"
    val bestStreakLabel = "أفضل سلسلة"
    val achievements = "الإنجازات"
    val settings = "الإعدادات"
    val soundEffects = "المؤثرات الصوتية"
    val hapticFeedback = "الاهتزاز اللمسي"
    val appLanguage = "لغة التطبيق"
    val appVersion = "الإصدار"
    val privacyPolicy = "سياسة الخصوصية"
    val termsOfService = "شروط الاستخدام"
    val resetProgress = "إعادة ضبط التقدم"
    val confirmReset = "هل أنت متأكد من مسح جميع النتائج والخبرة؟"
    val cancel = "إلغاء"
    val confirm = "تأكيد"
    val save = "حفظ"

    // Game HUD & Results
    val ready = "استعد"
    val go = "ابدأ"
    val score = "النتيجة"
    val combo = "مضاعف"
    val time = "الوقت"
    val pause = "إيقاف"
    val resume = "استئناف"
    val restart = "إعادة"
    val quit = "خروج"
    val gameOver = "انتهى الوقت"
    val greatJob = "أداء رائع"
    val newBestScore = "رقم قياسي جديد"
    val playAgain = "العب مرة أخرى"
    val nextLevel = "المستوى التالي"
    val backToGames = "العودة للألعاب"
}

val LocalStrings = staticCompositionLocalOf { Strings(AppLanguage.ARABIC) }

@Composable
fun ProvideLumoStrings(
    language: AppLanguage = AppLanguage.ARABIC,
    content: @Composable () -> Unit
) {
    val strings = Strings(language)
    CompositionLocalProvider(
        LocalStrings provides strings,
        content = content
    )
}
