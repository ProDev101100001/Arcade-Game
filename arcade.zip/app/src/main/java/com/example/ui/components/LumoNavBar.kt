package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.LocalSoundManager
import com.example.ui.LocalStrings
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoPrimaryLilac
import com.example.ui.theme.LumoTextPrimary
import com.example.ui.theme.LumoTextSecondary
import com.example.ui.theme.LumoTextTertiary

enum class LumoTab {
    HOME,
    GAMES,
    CHALLENGES,
    PROFILE
}

private data class NavItemSpec(
    val tab: LumoTab,
    val title: (strings: com.example.ui.Strings) -> String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

// RTL Order: Home (الرئيسية) on the right -> Games -> Challenges -> Profile on the left
private val NAV_ITEMS = listOf(
    NavItemSpec(
        tab = LumoTab.HOME,
        title = { it.tabHome },
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home,
        testTag = "nav_tab_home"
    ),
    NavItemSpec(
        tab = LumoTab.GAMES,
        title = { it.tabGames },
        selectedIcon = Icons.Filled.SportsEsports,
        unselectedIcon = Icons.Outlined.SportsEsports,
        testTag = "nav_tab_games"
    ),
    NavItemSpec(
        tab = LumoTab.CHALLENGES,
        title = { it.tabChallenges },
        selectedIcon = Icons.Filled.EmojiEvents,
        unselectedIcon = Icons.Outlined.EmojiEvents,
        testTag = "nav_tab_challenges"
    ),
    NavItemSpec(
        tab = LumoTab.PROFILE,
        title = { it.tabProfile },
        selectedIcon = Icons.Filled.Person,
        unselectedIcon = Icons.Outlined.Person,
        testTag = "nav_tab_profile"
    )
)

/**
 * Custom Curved Bottom Navigation Bar for Arcade (أركيد)
 * Faithfully recreating the visual identity from the reference design:
 * - Clean white navigation surface with rounded geometry
 * - Deep brand purple (#1800AD) active curved swoosh extending along the bottom and wrapping around the active tab edge
 * - Soft layered lilac underlay/shadow
 * - 4 clearly separated navigation items in natural Arabic RTL order
 * - Single designed component with comfortable touch targets and safe area insets
 */
@Composable
fun LumoBottomNavigationBar(
    currentTab: LumoTab,
    onTabSelected: (LumoTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val soundManager = LocalSoundManager.current
    val strings = LocalStrings.current

    // Active tab index in RTL (0 = Home, 1 = Games, 2 = Challenges, 3 = Profile)
    val activeIndex = when (currentTab) {
        LumoTab.HOME -> 0
        LumoTab.GAMES -> 1
        LumoTab.CHALLENGES -> 2
        LumoTab.PROFILE -> 3
    }

    // Smoothly animate active tab index position for dynamic fluid swoosh transitions
    val animatedIndex by animateFloatAsState(
        targetValue = activeIndex.toFloat(),
        animationSpec = spring(
            dampingRatio = 0.82f,
            stiffness = 380f
        ),
        label = "nav_swoosh_index"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        // Container height accommodating the white surface + the underlying purple curved swoosh
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(76.dp)
        ) {
            // Layer 1 & 2: Custom Canvas drawing the reference-inspired curved purple swoosh + lilac underlay
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
            ) {
                val barWidth = size.width
                val barHeight = size.height - 8.dp.toPx() // white bar height
                val tabCount = 4
                val tabWidth = barWidth / tabCount

                // Calculate center X of the active tab in RTL (Index 0 is at the right end of the bar in RTL)
                // In RTL layout coords: 0 is on the left in canvas pixels, but item 0 is rendered on the right!
                // So item 0 center = barWidth - (tabWidth * 0.5f)
                // Item 3 center = tabWidth * 0.5f
                val activeCenterX = barWidth - (animatedIndex * tabWidth) - (tabWidth * 0.5f)
                val isRightEdge = animatedIndex <= 0.35f
                val isLeftEdge = animatedIndex >= 2.65f

                val cornerRadius = 26.dp.toPx()
                val bottomY = barHeight
                val lilacColor = Color(0xFFC7D2FE)
                val primaryColor = Color(0xFF1800AD)

                // 1. Draw Lilac Underlay (Soft lower shadow/accent)
                val lilacPath = Path()
                if (isRightEdge) {
                    // Right end swoosh (wrapping around the right corner as shown in reference)
                    lilacPath.moveTo(cornerRadius * 0.5f, bottomY + 3.dp.toPx())
                    lilacPath.quadraticTo(
                        activeCenterX - 20.dp.toPx(),
                        bottomY + 5.dp.toPx(),
                        barWidth - 4.dp.toPx(),
                        bottomY + 6.dp.toPx()
                    )
                    lilacPath.cubicTo(
                        barWidth + 14.dp.toPx(),
                        bottomY + 2.dp.toPx(),
                        barWidth + 16.dp.toPx(),
                        bottomY - cornerRadius * 0.8f,
                        barWidth - 2.dp.toPx(),
                        bottomY - cornerRadius * 1.5f
                    )
                    lilacPath.cubicTo(
                        barWidth + 8.dp.toPx(),
                        bottomY - cornerRadius * 0.6f,
                        barWidth + 4.dp.toPx(),
                        bottomY + 1.dp.toPx(),
                        barWidth - cornerRadius * 0.6f,
                        bottomY + 2.dp.toPx()
                    )
                    lilacPath.quadraticTo(
                        activeCenterX - 30.dp.toPx(),
                        bottomY + 2.dp.toPx(),
                        cornerRadius * 0.5f,
                        bottomY + 1.dp.toPx()
                    )
                    lilacPath.close()
                } else if (isLeftEdge) {
                    // Left end swoosh (wrapping around the left corner)
                    lilacPath.moveTo(barWidth - cornerRadius * 0.5f, bottomY + 3.dp.toPx())
                    lilacPath.quadraticTo(
                        activeCenterX + 20.dp.toPx(),
                        bottomY + 5.dp.toPx(),
                        4.dp.toPx(),
                        bottomY + 6.dp.toPx()
                    )
                    lilacPath.cubicTo(
                        -14.dp.toPx(),
                        bottomY + 2.dp.toPx(),
                        -16.dp.toPx(),
                        bottomY - cornerRadius * 0.8f,
                        2.dp.toPx(),
                        bottomY - cornerRadius * 1.5f
                    )
                    lilacPath.cubicTo(
                        -8.dp.toPx(),
                        bottomY - cornerRadius * 0.6f,
                        -4.dp.toPx(),
                        bottomY + 1.dp.toPx(),
                        cornerRadius * 0.6f,
                        bottomY + 2.dp.toPx()
                    )
                    lilacPath.quadraticTo(
                        activeCenterX + 30.dp.toPx(),
                        bottomY + 2.dp.toPx(),
                        barWidth - cornerRadius * 0.5f,
                        bottomY + 1.dp.toPx()
                    )
                    lilacPath.close()
                } else {
                    // Mid tabs dynamic curved wave underlay
                    val startX = (activeCenterX - tabWidth * 0.75f).coerceAtLeast(10.dp.toPx())
                    val endX = (activeCenterX + tabWidth * 0.75f).coerceAtMost(barWidth - 10.dp.toPx())
                    lilacPath.moveTo(startX, bottomY + 2.dp.toPx())
                    lilacPath.quadraticTo(activeCenterX, bottomY + 7.dp.toPx(), endX, bottomY + 2.dp.toPx())
                    lilacPath.quadraticTo(activeCenterX, bottomY + 3.dp.toPx(), startX, bottomY + 2.dp.toPx())
                    lilacPath.close()
                }
                drawPath(lilacPath, color = lilacColor, style = Fill)

                // 2. Draw Main Brand Purple (#1800AD) Swoosh Ribbon
                val primaryPath = Path()
                if (isRightEdge) {
                    // Primary deep purple swoosh ribbon hugging bottom and curling up right side
                    primaryPath.moveTo(cornerRadius * 0.6f, bottomY - 0.5.dp.toPx())
                    primaryPath.quadraticTo(
                        activeCenterX - 24.dp.toPx(),
                        bottomY + 2.5.dp.toPx(),
                        barWidth - 2.dp.toPx(),
                        bottomY + 3.5.dp.toPx()
                    )
                    primaryPath.cubicTo(
                        barWidth + 10.dp.toPx(),
                        bottomY - 1.dp.toPx(),
                        barWidth + 11.dp.toPx(),
                        bottomY - cornerRadius * 0.9f,
                        barWidth - 4.dp.toPx(),
                        bottomY - cornerRadius * 1.6f
                    )
                    primaryPath.cubicTo(
                        barWidth + 4.dp.toPx(),
                        bottomY - cornerRadius * 0.7f,
                        barWidth + 1.dp.toPx(),
                        bottomY - 2.dp.toPx(),
                        barWidth - cornerRadius * 0.8f,
                        bottomY - 0.5.dp.toPx()
                    )
                    primaryPath.quadraticTo(
                        activeCenterX - 20.dp.toPx(),
                        bottomY - 0.5.dp.toPx(),
                        cornerRadius * 0.6f,
                        bottomY - 0.5.dp.toPx()
                    )
                    primaryPath.close()
                } else if (isLeftEdge) {
                    // Primary deep purple swoosh ribbon hugging bottom and curling up left side
                    primaryPath.moveTo(barWidth - cornerRadius * 0.6f, bottomY - 0.5.dp.toPx())
                    primaryPath.quadraticTo(
                        activeCenterX + 24.dp.toPx(),
                        bottomY + 2.5.dp.toPx(),
                        2.dp.toPx(),
                        bottomY + 3.5.dp.toPx()
                    )
                    primaryPath.cubicTo(
                        -10.dp.toPx(),
                        bottomY - 1.dp.toPx(),
                        -11.dp.toPx(),
                        bottomY - cornerRadius * 0.9f,
                        4.dp.toPx(),
                        bottomY - cornerRadius * 1.6f
                    )
                    primaryPath.cubicTo(
                        -4.dp.toPx(),
                        bottomY - cornerRadius * 0.7f,
                        -1.dp.toPx(),
                        bottomY - 2.dp.toPx(),
                        cornerRadius * 0.8f,
                        bottomY - 0.5.dp.toPx()
                    )
                    primaryPath.quadraticTo(
                        activeCenterX + 20.dp.toPx(),
                        bottomY - 0.5.dp.toPx(),
                        barWidth - cornerRadius * 0.6f,
                        bottomY - 0.5.dp.toPx()
                    )
                    primaryPath.close()
                } else {
                    // Mid tabs dynamic curved wave ribbon
                    val startX = (activeCenterX - tabWidth * 0.65f).coerceAtLeast(14.dp.toPx())
                    val endX = (activeCenterX + tabWidth * 0.65f).coerceAtMost(barWidth - 14.dp.toPx())
                    primaryPath.moveTo(startX, bottomY - 0.5.dp.toPx())
                    primaryPath.quadraticTo(activeCenterX, bottomY + 5.dp.toPx(), endX, bottomY - 0.5.dp.toPx())
                    primaryPath.quadraticTo(activeCenterX, bottomY + 1.5.dp.toPx(), startX, bottomY - 0.5.dp.toPx())
                    primaryPath.close()
                }
                drawPath(primaryPath, color = primaryColor, style = Fill)
            }

            // Layer 3: Main White Navigation Surface
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp)
                    .shadow(
                        elevation = 6.dp,
                        shape = RoundedCornerShape(26.dp),
                        ambientColor = Color(0x141800AD),
                        spotColor = Color(0x1F1800AD)
                    ),
                shape = RoundedCornerShape(26.dp),
                color = Color.White,
                tonalElevation = 0.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NAV_ITEMS.forEach { item ->
                        val isSelected = currentTab == item.tab
                        val labelText = item.title(strings)
                        val interactionSource = remember { MutableInteractionSource() }

                        val iconScale by animateFloatAsState(
                            targetValue = if (isSelected) 1.14f else 1.0f,
                            animationSpec = spring(dampingRatio = 0.75f),
                            label = "nav_icon_scale"
                        )

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clickable(
                                    interactionSource = interactionSource,
                                    indication = null
                                ) {
                                    if (!isSelected) {
                                        soundManager.playClick()
                                        onTabSelected(item.tab)
                                    }
                                }
                                .testTag(item.testTag),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = labelText,
                                    modifier = Modifier
                                        .size(24.dp)
                                        .scale(iconScale),
                                    tint = if (isSelected) LumoPrimary else Color(0xFF64748B)
                                )

                                Spacer(modifier = Modifier.height(3.dp))

                                Text(
                                    text = labelText,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) LumoPrimary else Color(0xFF64748B),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
