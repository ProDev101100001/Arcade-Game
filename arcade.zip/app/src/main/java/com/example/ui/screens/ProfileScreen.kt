package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AchievementEntity
import com.example.data.UserProfileEntity
import com.example.ui.AppLanguage
import com.example.ui.LocalStrings
import com.example.ui.components.LumoCard
import com.example.ui.components.LumoIconButton
import com.example.ui.components.LumoPrimaryButton
import com.example.ui.components.LumoProgressBar
import com.example.ui.components.LumoSecondaryButton
import com.example.ui.components.LumoTextButton
import com.example.ui.theme.LumoAmber
import com.example.ui.theme.LumoAmberLight
import com.example.ui.theme.LumoBackground
import com.example.ui.theme.LumoBorder
import com.example.ui.theme.LumoBorderSubtle
import com.example.ui.theme.LumoError
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoPrimaryLight
import com.example.ui.theme.LumoPrimarySurface
import com.example.ui.theme.LumoSuccess
import com.example.ui.theme.LumoSurface
import com.example.ui.theme.LumoTextPrimary
import com.example.ui.theme.LumoTextSecondary
import com.example.ui.theme.LumoTextTertiary

@Composable
fun ProfileScreen(
    profile: UserProfileEntity?,
    achievements: List<AchievementEntity>,
    currentLanguage: AppLanguage = AppLanguage.ARABIC,
    onLanguageSelected: (AppLanguage) -> Unit = {},
    onUpdateUsername: (String) -> Unit,
    onToggleSound: (Boolean) -> Unit,
    onToggleHaptic: (Boolean) -> Unit,
    onResetData: () -> Unit,
    onLogOut: (() -> Unit)? = null
) {
    val strings = LocalStrings.current
    var showEditNameDialog by remember { mutableStateOf(false) }
    var editNameInput by remember { mutableStateOf(profile?.username ?: "") }
    var showResetConfirmDialog by remember { mutableStateOf(false) }
    var showLogoutConfirmDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var dailyNotificationsEnabled by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(LumoBackground),
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = 12.dp,
            bottom = 32.dp
        ),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // 1. Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(top = 4.dp)
            ) {
                Text(
                    text = strings.playerProfile,
                    style = MaterialTheme.typography.displaySmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp
                    ),
                    color = LumoTextPrimary
                )
            }
        }

        // 2. Account Profile Card
        item {
            LumoCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = LumoSurface,
                borderColor = LumoBorder
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(LumoPrimarySurface)
                                    .border(1.5.dp, LumoPrimaryLight.copy(alpha = 0.4f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (profile?.username?.take(1) ?: "أ").uppercase(),
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        color = LumoPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }

                            Column {
                                Text(
                                    text = profile?.username ?: "لاعب",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                    color = LumoTextPrimary
                                )
                                Text(
                                    text = strings.guestAccount,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = LumoTextSecondary
                                )
                            }
                        }

                        LumoIconButton(
                            icon = Icons.Filled.Edit,
                            contentDescription = strings.editName,
                            onClick = {
                                editNameInput = profile?.username ?: ""
                                showEditNameDialog = true
                            },
                            size = 36.dp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // XP Progress
                    val currentXp = profile?.currentXp ?: 0
                    val targetXp = profile?.xpToNextLevel ?: 200
                    val progressFrac = (currentXp.toFloat() / targetXp).coerceIn(0f, 1f)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${strings.level} ${profile?.playerLevel ?: 1}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = LumoPrimary
                            )
                        )
                        Text(
                            text = "$currentXp / $targetXp ${strings.xp}",
                            style = MaterialTheme.typography.labelSmall,
                            color = LumoTextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    LumoProgressBar(progress = progressFrac, height = 6.dp)
                }
            }
        }

        // 3. Stats Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = strings.totalGamesPlayed,
                    value = "${profile?.totalGamesPlayed ?: 0}",
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = strings.bestStreakLabel,
                    value = "${profile?.bestStreak ?: 1}",
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = strings.achievements,
                    value = "${achievements.count { it.isUnlocked }} / ${achievements.size}",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 4. Section: Gameplay & Audio
        item {
            SettingsSection(title = strings.sectionGameplay) {
                // Sound Effects
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SettingIconBox(icon = Icons.Filled.VolumeUp, tint = LumoAmber, bg = LumoAmberLight)
                        Text(
                            text = strings.soundEffects,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = LumoTextPrimary
                        )
                    }

                    Switch(
                        checked = profile?.soundEnabled ?: true,
                        onCheckedChange = onToggleSound,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = LumoPrimary
                        )
                    )
                }

                HorizontalDivider(color = LumoBorderSubtle)

                // Haptic Feedback
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SettingIconBox(icon = Icons.Filled.Vibration, tint = LumoPrimary, bg = LumoPrimarySurface)
                        Text(
                            text = strings.hapticFeedback,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = LumoTextPrimary
                        )
                    }

                    Switch(
                        checked = profile?.hapticEnabled ?: true,
                        onCheckedChange = onToggleHaptic,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = LumoPrimary
                        )
                    )
                }
            }
        }

        // 6. Section: Notifications
        item {
            SettingsSection(title = strings.sectionNotifications) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SettingIconBox(icon = Icons.Filled.Notifications, tint = LumoAmber, bg = LumoAmberLight)
                        Text(
                            text = strings.dailyReminders,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = LumoTextPrimary
                        )
                    }

                    Switch(
                        checked = dailyNotificationsEnabled,
                        onCheckedChange = { dailyNotificationsEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = LumoPrimary
                        )
                    )
                }
            }
        }

        // 7. Section: Achievements
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = strings.achievements,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    ),
                    color = LumoTextPrimary
                )

                Spacer(modifier = Modifier.height(10.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    achievements.forEach { achievement ->
                        LumoCard(
                            modifier = Modifier.fillMaxWidth(),
                            backgroundColor = LumoSurface,
                            borderColor = LumoBorder
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (achievement.isUnlocked) LumoAmberLight else Color(0xFFF1F4F9)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (achievement.isUnlocked) Icons.Filled.Star else Icons.Filled.Lock,
                                            contentDescription = null,
                                            tint = if (achievement.isUnlocked) LumoAmber else LumoTextTertiary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    Column {
                                        Text(
                                            text = achievement.title,
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp
                                            ),
                                            color = LumoTextPrimary
                                        )
                                        Text(
                                            text = achievement.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = LumoTextSecondary
                                        )
                                    }
                                }

                                if (achievement.isUnlocked) {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = null,
                                        tint = LumoSuccess,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 8. Section: About & Danger Zone
        item {
            SettingsSection(title = strings.sectionAbout) {
                // App Version
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SettingIconBox(icon = Icons.Filled.Info, tint = LumoTextSecondary, bg = Color(0xFFF1F4F9))
                        Text(
                            text = strings.appVersion,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = LumoTextPrimary
                        )
                    }
                    Text(
                        text = "1.0.0",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = LumoTextSecondary
                    )
                }

                HorizontalDivider(color = LumoBorderSubtle)

                // Log out
                if (onLogOut != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showLogoutConfirmDialog = true },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            SettingIconBox(icon = Icons.AutoMirrored.Filled.Logout, tint = LumoTextSecondary, bg = Color(0xFFF1F4F9))
                            Text(
                                text = strings.logOut,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = LumoTextPrimary
                            )
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = LumoTextTertiary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    HorizontalDivider(color = LumoBorderSubtle)
                }

                // Reset Progress
                LumoTextButton(
                    text = strings.resetProgress,
                    textColor = LumoError,
                    onClick = { showResetConfirmDialog = true },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    // Edit Name Dialog
    if (showEditNameDialog) {
        AlertDialog(
            onDismissRequest = { showEditNameDialog = false },
            title = { Text(strings.editName, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = editNameInput,
                    onValueChange = { editNameInput = it },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (editNameInput.isNotBlank()) {
                            onUpdateUsername(editNameInput.trim())
                        }
                        showEditNameDialog = false
                    }
                ) {
                    Text(strings.save, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditNameDialog = false }) {
                    Text(strings.cancel)
                }
            }
        )
    }

    // Reset Confirm Dialog
    if (showResetConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showResetConfirmDialog = false },
            title = { Text(strings.resetProgress, fontWeight = FontWeight.Bold) },
            text = { Text(strings.confirmReset) },
            confirmButton = {
                TextButton(
                    onClick = {
                        onResetData()
                        showResetConfirmDialog = false
                    }
                ) {
                    Text(strings.confirm, color = LumoError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmDialog = false }) {
                    Text(strings.cancel)
                }
            }
        )
    }

    // Logout Confirm Dialog
    if (showLogoutConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirmDialog = false },
            title = { Text(strings.logOut, fontWeight = FontWeight.Bold) },
            text = { Text(strings.confirmLogout) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showLogoutConfirmDialog = false
                        onLogOut?.invoke()
                    }
                ) {
                    Text(strings.logOut, color = LumoPrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirmDialog = false }) {
                    Text(strings.cancel)
                }
            }
        )
    }
}

@Composable
private fun SettingsSection(
    title: String,
    content: @Composable () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            ),
            color = LumoTextPrimary
        )

        Spacer(modifier = Modifier.height(10.dp))

        LumoCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = LumoSurface,
            borderColor = LumoBorder
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                content()
            }
        }
    }
}

@Composable
private fun SettingIconBox(
    icon: ImageVector,
    tint: Color,
    bg: Color
) {
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(bg),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    LumoCard(
        modifier = modifier,
        backgroundColor = LumoSurface,
        borderColor = LumoBorder
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                ),
                color = LumoTextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = LumoTextSecondary,
                maxLines = 1
            )
        }
    }
}
