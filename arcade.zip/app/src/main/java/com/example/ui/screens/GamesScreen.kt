package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.LocalSoundManager
import com.example.data.GameProgressEntity
import com.example.ui.LocalStrings
import com.example.ui.components.CardColorChallengeArtwork
import com.example.ui.components.CardMemoryMatchArtwork
import com.example.ui.components.CardObstacleDodgeArtwork
import com.example.ui.components.CardOddOneOutArtwork
import com.example.ui.components.GameCardArtwork
import com.example.ui.components.HeroQuickTapArtwork
import com.example.ui.theme.LumoAmber
import com.example.ui.theme.LumoBackground
import com.example.ui.theme.LumoBorder
import com.example.ui.theme.LumoBorderSubtle
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoPrimarySurface
import com.example.ui.theme.LumoSurface
import com.example.ui.theme.LumoTextPrimary
import com.example.ui.theme.LumoTextSecondary
import com.example.ui.theme.LumoTextTertiary
import kotlinx.coroutines.launch

private data class ArcadeGameCatalogItem(
    val id: String,
    val targetEngineId: String,
    val title: String,
    val subtitle: String,
    val level: Int,
    val highScore: String,
    val categoryKey: String,
    val artworkType: String
)

@Composable
fun GamesScreen(
    allGamesProgress: List<GameProgressEntity>,
    onSelectGame: (String) -> Unit
) {
    val strings = LocalStrings.current
    val soundManager = LocalSoundManager.current
    var selectedCategory by remember { mutableStateOf("ALL") }

    val quickTapProg = allGamesProgress.find { it.gameId == "quick_tap" }
    val memoryProg = allGamesProgress.find { it.gameId == "memory_match" }
    val oddProg = allGamesProgress.find { it.gameId == "odd_one_out" }

    val featuredBestScore = if ((quickTapProg?.highScore ?: 0) > 0) {
        "${quickTapProg?.highScore}ms"
    } else {
        "0.28 ثانية"
    }

    // Comprehensive curated arcade catalog logically sorted
    val quickGames = remember(allGamesProgress) {
        listOf(
            ArcadeGameCatalogItem(
                id = "quick_tap",
                targetEngineId = "quick_tap",
                title = strings.quickTapTitle,
                subtitle = "سرعة وردة فعل",
                level = quickTapProg?.currentLevel ?: 4,
                highScore = if ((quickTapProg?.highScore ?: 0) > 0) "${quickTapProg?.highScore}" else "820",
                categoryKey = "REFLEX",
                artworkType = "color_challenge"
            ),
            ArcadeGameCatalogItem(
                id = "obstacle_dodge",
                targetEngineId = "quick_tap",
                title = strings.obstacleDodgeTitle,
                subtitle = strings.obstacleDodgeSub,
                level = 2,
                highScore = "680",
                categoryKey = "REFLEX",
                artworkType = "obstacle_dodge"
            ),
            ArcadeGameCatalogItem(
                id = "reaction_time",
                targetEngineId = "quick_tap",
                title = strings.reactionTimeTitle,
                subtitle = "اختبار التوقيت",
                level = 1,
                highScore = "420",
                categoryKey = "REFLEX",
                artworkType = "reaction_time"
            )
        )
    }

    val memoryGames = remember(allGamesProgress) {
        listOf(
            ArcadeGameCatalogItem(
                id = "memory_match",
                targetEngineId = "memory_match",
                title = strings.memoryMatchTitle,
                subtitle = "اكشف الأزواج",
                level = memoryProg?.currentLevel ?: 4,
                highScore = if ((memoryProg?.highScore ?: 0) > 0) "${memoryProg?.highScore}" else "950",
                categoryKey = "MEMORY",
                artworkType = "memory_match"
            ),
            ArcadeGameCatalogItem(
                id = "memory_sequence",
                targetEngineId = "memory_match",
                title = strings.memorySequenceTitle,
                subtitle = "احفظ النمط",
                level = 3,
                highScore = "1,150",
                categoryKey = "MEMORY",
                artworkType = "memory_sequence"
            )
        )
    }

    val focusGames = remember(allGamesProgress) {
        listOf(
            ArcadeGameCatalogItem(
                id = "odd_one_out",
                targetEngineId = "odd_one_out",
                title = strings.oddOneOutTitle,
                subtitle = "اعثر على المختلف",
                level = oddProg?.currentLevel ?: 5,
                highScore = if ((oddProg?.highScore ?: 0) > 0) "${oddProg?.highScore}" else "1,200",
                categoryKey = "FOCUS",
                artworkType = "odd_one_out"
            ),
            ArcadeGameCatalogItem(
                id = "speed_math",
                targetEngineId = "odd_one_out",
                title = strings.speedMathTitle,
                subtitle = "حساب سريع ودقيق",
                level = 2,
                highScore = "740",
                categoryKey = "FOCUS",
                artworkType = "speed_math"
            ),
            ArcadeGameCatalogItem(
                id = "number_order",
                targetEngineId = "memory_match",
                title = strings.numberOrderTitle,
                subtitle = "ترتيب الأرقام",
                level = 3,
                highScore = "890",
                categoryKey = "FOCUS",
                artworkType = "number_order"
            )
        )
    }

    val newArcadeGames = remember {
        listOf(
            ArcadeGameCatalogItem(
                id = "obstacle_dodge",
                targetEngineId = "quick_tap",
                title = strings.obstacleDodgeTitle,
                subtitle = strings.obstacleDodgeSub,
                level = 2,
                highScore = "680",
                categoryKey = "NEW",
                artworkType = "obstacle_dodge"
            ),
            ArcadeGameCatalogItem(
                id = "reaction_time",
                targetEngineId = "quick_tap",
                title = strings.reactionTimeTitle,
                subtitle = "سرعة اللمس الفورية",
                level = 1,
                highScore = "420",
                categoryKey = "NEW",
                artworkType = "reaction_time"
            )
        )
    }

    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isVisible = true
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(LumoBackground),
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = 10.dp,
            bottom = 90.dp
        ),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        // ==========================================
        // 1. Header (Clean, Punchy, Arabic RTL)
        // ==========================================
        item {
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(tween(300)) + slideInVertically(tween(300)) { -15 }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(top = 4.dp)
                ) {
                    Text(
                        text = strings.gameLibraryTitle,
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 28.sp,
                            color = LumoTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = strings.gameLibrarySubtitle,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = LumoTextSecondary
                        )
                    )
                }
            }
        }

        // ==========================================
        // 2. Sleek Arcade Category Tabs
        // ==========================================
        item {
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(tween(350, delayMillis = 50))
            ) {
                ArcadeCategoryTabs(
                    selectedKey = selectedCategory,
                    onSelectCategory = { key ->
                        soundManager.playTap()
                        selectedCategory = key
                    }
                )
            }
        }

        // ==========================================
        // 3. Dominant Large Featured Game Hero Card
        // ==========================================
        if (selectedCategory == "ALL" || selectedCategory == "REFLEX") {
            item {
                AnimatedVisibility(
                    visible = isVisible,
                    enter = fadeIn(tween(400, delayMillis = 80)) + slideInVertically(tween(400, delayMillis = 80)) { 20 }
                ) {
                    LargeFeaturedGameCard(
                        title = strings.quickTapTitle,
                        subtitle = "هل تستطيع تحطيم رقمك القياسي؟",
                        bestScore = featuredBestScore,
                        onPlay = {
                            soundManager.playClick()
                            onSelectGame("quick_tap")
                        }
                    )
                }
            }
        }

        // ==========================================
        // 4. Section: ألعاب سريعة (Reflex Games)
        // ==========================================
        if (selectedCategory == "ALL" || selectedCategory == "REFLEX") {
            item {
                ArcadeGameSection(
                    title = strings.colQuickGames,
                    subtitle = strings.colQuickGamesSub,
                    games = quickGames,
                    onSelectGame = { engineId ->
                        soundManager.playClick()
                        onSelectGame(engineId)
                    }
                )
            }
        }

        // ==========================================
        // 5. Section: الذاكرة (Memory Games)
        // ==========================================
        if (selectedCategory == "ALL" || selectedCategory == "MEMORY") {
            item {
                ArcadeGameSection(
                    title = strings.colMemoryGames,
                    subtitle = strings.colMemoryGamesSub,
                    games = memoryGames,
                    onSelectGame = { engineId ->
                        soundManager.playClick()
                        onSelectGame(engineId)
                    }
                )
            }
        }

        // ==========================================
        // 6. Section: التركيز (Focus Games)
        // ==========================================
        if (selectedCategory == "ALL" || selectedCategory == "FOCUS") {
            item {
                ArcadeGameSection(
                    title = strings.colFocusGames,
                    subtitle = strings.colFocusGamesSub,
                    games = focusGames,
                    onSelectGame = { engineId ->
                        soundManager.playClick()
                        onSelectGame(engineId)
                    }
                )
            }
        }

        // ==========================================
        // 7. Section: جديد في أركيد (New in Arcade)
        // ==========================================
        if (selectedCategory == "ALL" || selectedCategory == "NEW") {
            item {
                ArcadeGameSection(
                    title = strings.newArcade,
                    subtitle = "أحدث الألعاب المضافة",
                    games = newArcadeGames,
                    onSelectGame = { engineId ->
                        soundManager.playClick()
                        onSelectGame(engineId)
                    }
                )
            }
        }
    }
}

// -------------------------------------------------------------------
// Component: Sleek Category Navigation Tabs (Fast 180ms anim, RTL)
// -------------------------------------------------------------------

@Composable
private fun ArcadeCategoryTabs(
    selectedKey: String,
    onSelectCategory: (String) -> Unit
) {
    val strings = LocalStrings.current
    val categories = listOf(
        Triple("ALL", strings.catAll, Icons.Filled.GridView),
        Triple("REFLEX", strings.catReflex, Icons.Filled.Bolt),
        Triple("MEMORY", strings.catMemory, Icons.Filled.Psychology),
        Triple("FOCUS", strings.catFocus, Icons.Filled.Visibility),
        Triple("NEW", strings.catNew, Icons.Filled.AutoAwesome)
    )

    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 2.dp)
    ) {
        items(categories) { (key, label, icon) ->
            val isSelected = selectedKey == key

            val bgColor by animateColorAsState(
                targetValue = if (isSelected) LumoPrimary else LumoSurface,
                animationSpec = tween(180, easing = FastOutSlowInEasing),
                label = "tab_bg"
            )
            val textColor by animateColorAsState(
                targetValue = if (isSelected) Color.White else LumoTextPrimary,
                animationSpec = tween(180, easing = FastOutSlowInEasing),
                label = "tab_text"
            )
            val iconColor by animateColorAsState(
                targetValue = if (isSelected) Color.White else LumoTextSecondary,
                animationSpec = tween(180, easing = FastOutSlowInEasing),
                label = "tab_icon"
            )
            val borderColor by animateColorAsState(
                targetValue = if (isSelected) LumoPrimary else LumoBorder,
                animationSpec = tween(180, easing = FastOutSlowInEasing),
                label = "tab_border"
            )

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(bgColor)
                    .border(1.dp, borderColor, RoundedCornerShape(16.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        onSelectCategory(key)
                    }
                    .padding(horizontal = 14.dp, vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 13.sp,
                            color = textColor
                        )
                    )
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp),
                        tint = iconColor
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------------
// Component: Large Dominant Featured Game Hero Card (#1800AD + Art)
// -------------------------------------------------------------------

@Composable
private fun LargeFeaturedGameCard(
    title: String,
    subtitle: String,
    bestScore: String,
    onPlay: () -> Unit
) {
    val strings = LocalStrings.current
    val scale = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale.value)
            .shadow(16.dp, RoundedCornerShape(24.dp), spotColor = LumoPrimary.copy(alpha = 0.35f))
            .clip(RoundedCornerShape(24.dp))
            .background(
                brush = Brush.linearGradient(
                    listOf(Color(0xFF1800AD), Color(0xFF2610C8), Color(0xFF0E006B))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(24.dp))
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        scope.launch { scale.animateTo(0.98f, spring(stiffness = Spring.StiffnessMediumLow)) }
                        tryAwaitRelease()
                        scope.launch { scale.animateTo(1f, spring(stiffness = Spring.StiffnessMediumLow)) }
                    },
                    onTap = { onPlay() }
                )
            }
            .padding(20.dp)
            .testTag("large_featured_game_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Text Details & White CTA
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 12.dp)
            ) {
                // Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.16f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "لعبة اليوم المميزة",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 11.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = Color.White
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Best Score Pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Timer,
                        contentDescription = null,
                        tint = Color(0xFFFDE047),
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = "${strings.bestScore} $bestScore",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color.White
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Primary White CTA Button
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onPlay() }
                        .shadow(4.dp, RoundedCornerShape(12.dp), spotColor = Color.Black.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = strings.playNow,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = LumoPrimary
                            )
                        )
                        Icon(
                            imageVector = Icons.Filled.PlayArrow,
                            contentDescription = null,
                            tint = LumoPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Visual Artwork Canvas on Left (RTL context)
            Box(
                modifier = Modifier
                    .size(118.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                HeroQuickTapArtwork()
            }
        }
    }
}

// -------------------------------------------------------------------
// Component: Curated Arcade Game Section
// -------------------------------------------------------------------

@Composable
private fun ArcadeGameSection(
    title: String,
    subtitle: String,
    games: List<ArcadeGameCatalogItem>,
    onSelectGame: (String) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section Title & Subtitle
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = LumoTextPrimary
                )
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = LumoTextSecondary
                )
            )
        }

        // 2-Column Grid of Game Cards
        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            games.chunked(2).forEach { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowItems.forEach { gameItem ->
                        Box(
                            modifier = Modifier.weight(1f)
                        ) {
                            ArcadeMediumGameCard(
                                item = gameItem,
                                onClick = { onSelectGame(gameItem.targetEngineId) }
                            )
                        }
                    }
                    if (rowItems.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------
// Component: Medium Artwork-First Game Card (Entire Card Clickable)
// -------------------------------------------------------------------

@Composable
private fun ArcadeMediumGameCard(
    item: ArcadeGameCatalogItem,
    onClick: () -> Unit
) {
    val strings = LocalStrings.current
    val scale = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale.value)
            .shadow(4.dp, RoundedCornerShape(18.dp), spotColor = LumoPrimary.copy(alpha = 0.08f))
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, LumoBorder, RoundedCornerShape(18.dp))
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        scope.launch { scale.animateTo(0.97f, spring(stiffness = Spring.StiffnessMediumLow)) }
                        tryAwaitRelease()
                        scope.launch { scale.animateTo(1f, spring(stiffness = Spring.StiffnessMediumLow)) }
                    },
                    onTap = { onClick() }
                )
            }
            .testTag("arcade_game_card_${item.id}"),
        shape = RoundedCornerShape(18.dp),
        color = LumoSurface
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Artwork Hero Canvas (Top 65%)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(115.dp)
                    .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
            ) {
                GameCardArtwork(gameId = item.artworkType)
            }

            // Card Text Details
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = LumoTextPrimary
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = item.subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = LumoTextSecondary
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Level & Trophy Score Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${strings.level} ${item.level}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp,
                            color = LumoTextSecondary
                        )
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.EmojiEvents,
                            contentDescription = null,
                            tint = LumoAmber,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = item.highScore,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = LumoTextPrimary
                            )
                        )
                    }
                }
            }
        }
    }
}
