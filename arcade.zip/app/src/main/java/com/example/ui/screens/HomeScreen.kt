package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.LocalSoundManager
import com.example.data.GameProgressEntity
import com.example.data.UserProfileEntity
import com.example.games.GameRegistry
import com.example.ui.LocalStrings
import com.example.ui.components.GameCardArtwork
import com.example.ui.components.GameHeroArtwork
import com.example.ui.theme.LumoAmber
import com.example.ui.theme.LumoAmberDark
import com.example.ui.theme.LumoAmberLight
import com.example.ui.theme.LumoBackground
import com.example.ui.theme.LumoBorder
import com.example.ui.theme.LumoBorderSubtle
import com.example.ui.theme.LumoCoral
import com.example.ui.theme.LumoCoralDark
import com.example.ui.theme.LumoCoralLight
import com.example.ui.theme.LumoCyan
import com.example.ui.theme.LumoEmerald
import com.example.ui.theme.LumoEmeraldDark
import com.example.ui.theme.LumoEmeraldLight
import com.example.ui.theme.LumoIris
import com.example.ui.theme.LumoIrisDark
import com.example.ui.theme.LumoIrisLight
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoPrimaryDark
import com.example.ui.theme.LumoPrimaryLight
import com.example.ui.theme.LumoPrimarySurface
import com.example.ui.theme.LumoSurface
import com.example.ui.theme.LumoTextPrimary
import com.example.ui.theme.LumoTextSecondary
import com.example.ui.theme.LumoTextTertiary
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    profile: UserProfileEntity?,
    allGamesProgress: List<GameProgressEntity>,
    onPlayGame: (String) -> Unit,
    onNavigateToChallenges: () -> Unit,
    onNavigateToGames: () -> Unit
) {
    val strings = LocalStrings.current
    val soundManager = LocalSoundManager.current

    // Determine featured / recommended game
    val featuredGameId = profile?.lastPlayedGameId ?: "quick_tap"
    val featuredGame = GameRegistry.getGameById(featuredGameId)
    val featuredProgress = allGamesProgress.find { it.gameId == featuredGameId }

    // Staggered Entrance Animations
    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isVisible = true
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(LumoBackground),
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = 10.dp,
            bottom = 32.dp
        ),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // ==========================================
        // 1. Header (Greeting + Compact Player Badge)
        // ==========================================
        item {
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(tween(400)) + slideInVertically(tween(400)) { -20 }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Start side: Greeting & Subtitle
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "${strings.greetingHello} ${profile?.username ?: "لاعب"}",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = LumoTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = strings.readyForQuickRound,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 13.sp,
                                color = LumoTextSecondary
                            )
                        )
                    }

                    // End side: Compact Player Avatar & Level Pill
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(LumoSurface)
                            .border(1.dp, LumoBorderSubtle, RoundedCornerShape(20.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        // Level Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(LumoPrimarySurface)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${strings.level} ${profile?.playerLevel ?: 1}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = LumoPrimary,
                                    fontSize = 11.sp
                                )
                            )
                        }

                        // Mini Streak Pill
                        if ((profile?.currentStreak ?: 0) > 0) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.LocalFireDepartment,
                                    contentDescription = null,
                                    tint = LumoCoral,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = "${profile?.currentStreak}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = LumoCoral,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }

                        // Avatar Initial Circle
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.linearGradient(
                                        listOf(LumoPrimary, LumoPrimaryDark)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (profile?.username?.take(1) ?: "أ").uppercase(),
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 12.sp
                                )
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // 2. PRIMARY HERO (The Star Focal Point)
        // ==========================================
        item {
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(tween(500, delayMillis = 100)) + slideInVertically(tween(500, delayMillis = 100)) { 30 }
            ) {
                HeroGameCard(
                    gameId = featuredGame.id,
                    title = featuredGame.getTitle(strings),
                    bestScore = formatGameBestScore(featuredGame.id, featuredProgress?.highScore ?: 0, strings),
                    level = featuredProgress?.currentLevel ?: 1,
                    onPlay = {
                        soundManager.playClick()
                        onPlayGame(featuredGame.id)
                    }
                )
            }
        }

        // ==========================================
        // 3. Daily Challenge (Compact & Catchy)
        // ==========================================
        item {
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(tween(500, delayMillis = 200)) + slideInVertically(tween(500, delayMillis = 200)) { 30 }
            ) {
                DailyChallengeCompactCard(
                    onStartChallenge = {
                        soundManager.playTap()
                        onNavigateToChallenges()
                    }
                )
            }
        }

        // ==========================================
        // 4. Games Section ("ألعاب اليوم")
        // ==========================================
        item {
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(tween(500, delayMillis = 300)) + slideInVertically(tween(500, delayMillis = 300)) { 30 }
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Section Title Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.todayGames,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = LumoTextPrimary
                            )
                        )

                        Text(
                            text = strings.viewAll,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = LumoPrimary,
                                fontSize = 13.sp
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable {
                                    soundManager.playTap()
                                    onNavigateToGames()
                                }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }

                    // Game Cards List
                    GameRegistry.allGames.forEach { game ->
                        val progress = allGamesProgress.find { it.gameId == game.id }
                        ArcadeGameCard(
                            gameId = game.id,
                            title = game.getTitle(strings),
                            level = progress?.currentLevel ?: 1,
                            bestScore = formatGameBestScore(game.id, progress?.highScore ?: 0, strings),
                            onClick = {
                                soundManager.playClick()
                                onPlayGame(game.id)
                            }
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------
// Component: Primary Hero Game Card
// -------------------------------------------------------------------

@Composable
private fun HeroGameCard(
    gameId: String,
    title: String,
    bestScore: String,
    level: Int,
    onPlay: () -> Unit
) {
    val strings = LocalStrings.current
    val scale = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale.value)
            .shadow(16.dp, RoundedCornerShape(24.dp), spotColor = LumoPrimary.copy(alpha = 0.35f))
            .clip(RoundedCornerShape(24.dp))
            .background(
                brush = Brush.linearGradient(
                    listOf(Color(0xFF1800AD), Color(0xFF2610C8), Color(0xFF0E006B))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(24.dp))
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        scope.launch { scale.animateTo(0.97f, spring(stiffness = Spring.StiffnessMediumLow)) }
                        tryAwaitRelease()
                        scope.launch { scale.animateTo(1f, spring(stiffness = Spring.StiffnessMediumLow)) }
                    },
                    onTap = { onPlay() }
                )
            }
            .padding(20.dp)
            .testTag("hero_game_card")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Top Row: Suggestion Tag + Level Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Suggestion Tag
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.16f))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Star,
                            contentDescription = null,
                            tint = LumoAmber,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = strings.suggestedForYou,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                // Level Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.16f))
                        .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${strings.level} $level",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Center: Game Title & Artwork Canvas
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.displaySmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            color = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    // Best Score Chip
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.TrendingUp,
                            contentDescription = null,
                            tint = LumoAmber,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "${strings.bestScore}: $bestScore",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Medium,
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 13.sp
                            )
                        )
                    }
                }

                // Game Visual Artwork Motif
                Box(
                    modifier = Modifier
                        .size(110.dp, 100.dp),
                    contentAlignment = Alignment.Center
                ) {
                    GameHeroArtwork(gameId = gameId)
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // CTA Button: White Background + #1800AD Text
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onPlay() }
                    .shadow(4.dp, RoundedCornerShape(14.dp), spotColor = Color.Black.copy(alpha = 0.15f))
                    .testTag("hero_play_button"),
                shape = RoundedCornerShape(14.dp),
                color = Color.White
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = strings.playNow,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = LumoPrimary
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = null,
                        tint = LumoPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------------
// Component: Compact Daily Challenge Card
// -------------------------------------------------------------------

@Composable
private fun DailyChallengeCompactCard(
    onStartChallenge: () -> Unit
) {
    val strings = LocalStrings.current
    val scale = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale.value)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        scope.launch { scale.animateTo(0.98f, spring(stiffness = Spring.StiffnessMediumLow)) }
                        tryAwaitRelease()
                        scope.launch { scale.animateTo(1f, spring(stiffness = Spring.StiffnessMediumLow)) }
                    },
                    onTap = { onStartChallenge() }
                )
            }
            .testTag("daily_challenge_card"),
        shape = RoundedCornerShape(18.dp),
        color = LumoSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, LumoBorderSubtle),
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Trophy Icon
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(LumoAmberLight),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.EmojiEvents,
                    contentDescription = null,
                    tint = LumoAmberDark,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Challenge Title & XP Specs
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = strings.dailyChallenge,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = LumoTextPrimary
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (strings.lang == com.example.ui.AppLanguage.ARABIC) "3 ألعاب" else "3 Games",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = LumoTextSecondary,
                            fontSize = 12.sp
                        )
                    )
                    Text(
                        text = "•",
                        style = MaterialTheme.typography.bodySmall.copy(color = LumoTextTertiary)
                    )
                    Text(
                        text = "+150 XP",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = LumoAmberDark,
                            fontSize = 12.sp
                        )
                    )
                }
            }

            // Start Action Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(LumoPrimarySurface)
                    .padding(horizontal = 12.dp, vertical = 7.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = strings.start,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = LumoPrimary,
                            fontSize = 12.sp
                        )
                    )
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = LumoPrimary,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------------
// Component: Arcade Game Card (With Artwork & Tactile Scale)
// -------------------------------------------------------------------

@Composable
private fun ArcadeGameCard(
    gameId: String,
    title: String,
    level: Int,
    bestScore: String,
    onClick: () -> Unit
) {
    val strings = LocalStrings.current
    val scale = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()

    val (accentColor, bgTint) = when (gameId) {
        "quick_tap" -> Pair(LumoCoral, LumoCoralLight)
        "memory_match" -> Pair(LumoIris, LumoIrisLight)
        "odd_one_out" -> Pair(LumoEmerald, LumoEmeraldLight)
        else -> Pair(LumoPrimary, LumoPrimarySurface)
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale.value)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        scope.launch { scale.animateTo(0.97f, spring(stiffness = Spring.StiffnessMediumLow)) }
                        tryAwaitRelease()
                        scope.launch { scale.animateTo(1f, spring(stiffness = Spring.StiffnessMediumLow)) }
                    },
                    onTap = { onClick() }
                )
            }
            .testTag("arcade_game_card_$gameId"),
        shape = RoundedCornerShape(20.dp),
        color = LumoSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, LumoBorderSubtle),
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Game Visual Artwork Container
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(bgTint)
                    .border(1.dp, accentColor.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                GameCardArtwork(gameId = gameId, modifier = Modifier.fillMaxSize())
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Game Name & Metadata
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = LumoTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Level Pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(accentColor.copy(alpha = 0.12f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${strings.level} $level",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = accentColor,
                                fontSize = 11.sp
                            )
                        )
                    }

                    // Best Score
                    Text(
                        text = "${strings.bestScore}: $bestScore",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = LumoTextSecondary,
                            fontSize = 12.sp
                        )
                    )
                }
            }

            // Arrow Indicator
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(LumoBackground),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = LumoTextTertiary,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

// -------------------------------------------------------------------
// Helper Formatter
// -------------------------------------------------------------------

private fun formatGameBestScore(
    gameId: String,
    score: Int,
    strings: com.example.ui.Strings
): String {
    if (score <= 0) return "--"
    return when (gameId) {
        "quick_tap" -> "${score}ms"
        "memory_match" -> "$score ${if (strings.lang == com.example.ui.AppLanguage.ARABIC) "ث" else "s"}"
        "odd_one_out" -> "$score"
        else -> "$score"
    }
}
