package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.AppLanguage

// Google Font Provider Setup
private val googleFontProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = R.array.com_google_android_gms_fonts_certs
)

// Primary Arabic Font: IBM Plex Sans Arabic
private val ibmPlexSansArabic = GoogleFont("IBM Plex Sans Arabic")
val ArabicFontFamily = FontFamily(
    Font(googleFont = ibmPlexSansArabic, fontProvider = googleFontProvider, weight = FontWeight.Normal),
    Font(googleFont = ibmPlexSansArabic, fontProvider = googleFontProvider, weight = FontWeight.Medium),
    Font(googleFont = ibmPlexSansArabic, fontProvider = googleFontProvider, weight = FontWeight.SemiBold),
    Font(googleFont = ibmPlexSansArabic, fontProvider = googleFontProvider, weight = FontWeight.Bold)
)

// Primary English & Numeric Font: Inter
private val interGoogleFont = GoogleFont("Inter")
val EnglishFontFamily = FontFamily(
    Font(googleFont = interGoogleFont, fontProvider = googleFontProvider, weight = FontWeight.Normal),
    Font(googleFont = interGoogleFont, fontProvider = googleFontProvider, weight = FontWeight.Medium),
    Font(googleFont = interGoogleFont, fontProvider = googleFontProvider, weight = FontWeight.SemiBold),
    Font(googleFont = interGoogleFont, fontProvider = googleFontProvider, weight = FontWeight.Bold)
)

// Tabular / Monospace Numeral Font for Timers & Speed meters
val NumericFontFamily = EnglishFontFamily

/**
 * Returns dynamic Material 3 Typography calibrated specifically for the selected language.
 * Arabic receives comfortable line-heights and neutral tracking (0.sp).
 * English receives refined optical tracking and modern scale.
 */
fun getAppTypography(language: AppLanguage): Typography {
    val isArabic = language == AppLanguage.ARABIC
    val family = if (isArabic) ArabicFontFamily else EnglishFontFamily
    val letterSpacingDisplay = if (isArabic) 0.sp else (-0.5).sp
    val letterSpacingHeadline = if (isArabic) 0.sp else (-0.2).sp
    val letterSpacingBody = if (isArabic) 0.sp else 0.1.sp

    return Typography(
        // Large Hero & Countdown (32–36sp)
        displayLarge = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Black,
            fontSize = 34.sp,
            lineHeight = 42.sp,
            letterSpacing = letterSpacingDisplay,
            color = LumoTextPrimary
        ),
        displayMedium = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Bold,
            fontSize = 28.sp,
            lineHeight = 36.sp,
            letterSpacing = letterSpacingDisplay,
            color = LumoTextPrimary
        ),
        displaySmall = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            lineHeight = 32.sp,
            letterSpacing = letterSpacingHeadline,
            color = LumoTextPrimary
        ),

        // Section Titles (H1: 22–26sp, H2: 20sp, H3: 18sp)
        headlineLarge = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            lineHeight = 32.sp,
            letterSpacing = letterSpacingHeadline,
            color = LumoTextPrimary
        ),
        headlineMedium = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.SemiBold,
            fontSize = 20.sp,
            lineHeight = 28.sp,
            letterSpacing = letterSpacingHeadline,
            color = LumoTextPrimary
        ),
        headlineSmall = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.SemiBold,
            fontSize = 18.sp,
            lineHeight = 26.sp,
            letterSpacing = 0.sp,
            color = LumoTextPrimary
        ),

        // Card Headers & Game Titles (16–18sp)
        titleLarge = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            lineHeight = 24.sp,
            letterSpacing = 0.sp,
            color = LumoTextPrimary
        ),
        titleMedium = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.SemiBold,
            fontSize = 16.sp,
            lineHeight = 22.sp,
            letterSpacing = 0.sp,
            color = LumoTextPrimary
        ),
        titleSmall = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Medium,
            fontSize = 14.sp,
            lineHeight = 20.sp,
            letterSpacing = 0.sp,
            color = LumoTextSecondary
        ),

        // Body & Explanatory text (12–15sp)
        bodyLarge = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Normal,
            fontSize = 15.sp,
            lineHeight = 22.sp,
            letterSpacing = letterSpacingBody,
            color = LumoTextPrimary
        ),
        bodyMedium = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Normal,
            fontSize = 14.sp,
            lineHeight = 20.sp,
            letterSpacing = letterSpacingBody,
            color = LumoTextSecondary
        ),
        bodySmall = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Normal,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            letterSpacing = letterSpacingBody,
            color = LumoTextTertiary
        ),

        // Buttons, Chips & Interactive Labels (11–14sp)
        labelLarge = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            lineHeight = 18.sp,
            letterSpacing = if (isArabic) 0.sp else 0.1.sp,
            color = LumoTextPrimary
        ),
        labelMedium = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            lineHeight = 16.sp,
            letterSpacing = if (isArabic) 0.sp else 0.2.sp,
            color = LumoTextSecondary
        ),
        labelSmall = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Medium,
            fontSize = 11.sp,
            lineHeight = 15.sp,
            letterSpacing = if (isArabic) 0.sp else 0.2.sp,
            color = LumoTextTertiary
        )
    )
}

/**
 * Dedicated high-precision Typography styles for game timers, scores, and HUD metrics.
 */
object LumoTypographyExt {
    // Large Gameplay Timer (Tabular Numbers)
    val timerLarge = TextStyle(
        fontFamily = NumericFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        lineHeight = 32.sp,
        letterSpacing = 0.5.sp,
        color = LumoTextPrimary
    )

    // HUD Header Timer / Reaction Counter
    val timerHud = TextStyle(
        fontFamily = NumericFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.3.sp,
        color = LumoTextPrimary
    )

    // Huge Score Counter (Results Screen)
    val scoreHero = TextStyle(
        fontFamily = NumericFontFamily,
        fontWeight = FontWeight.Black,
        fontSize = 48.sp,
        lineHeight = 54.sp,
        letterSpacing = (-0.5).sp,
        color = LumoTextPrimary
    )

    // HUD Live Score
    val scoreHud = TextStyle(
        fontFamily = NumericFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.2.sp,
        color = LumoTextPrimary
    )

    // Level Badge Text
    val levelPill = TextStyle(
        fontFamily = NumericFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        lineHeight = 14.sp
    )
}

val Typography = getAppTypography(AppLanguage.ARABIC)
