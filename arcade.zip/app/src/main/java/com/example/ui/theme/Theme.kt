package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LumoLightColorScheme = lightColorScheme(
    primary = LumoPrimary,
    onPrimary = LumoTextInverse,
    primaryContainer = LumoPrimarySurface,
    onPrimaryContainer = LumoPrimaryDark,
    secondary = LumoCoral,
    onSecondary = LumoTextInverse,
    secondaryContainer = LumoCoralLight,
    onSecondaryContainer = LumoCoral,
    tertiary = LumoAmber,
    onTertiary = LumoTextInverse,
    tertiaryContainer = LumoAmberLight,
    onTertiaryContainer = LumoAmberDark,
    background = LumoBackground,
    onBackground = LumoTextPrimary,
    surface = LumoSurface,
    onSurface = LumoTextPrimary,
    surfaceVariant = LumoSurfaceVariant,
    onSurfaceVariant = LumoTextSecondary,
    outline = LumoBorder,
    outlineVariant = LumoBorderSubtle
)

private val LumoDarkColorScheme = darkColorScheme(
    primary = LumoPrimaryLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF312E81),
    onPrimaryContainer = Color(0xFFEEF2FF),
    secondary = LumoCoral,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF7F1D1D),
    onSecondaryContainer = Color(0xFFFEE2E2),
    tertiary = LumoAmber,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF78350F),
    onTertiaryContainer = Color(0xFFFEF3C7),
    background = Color(0xFF0F172A),
    onBackground = Color(0xFFF8FAFC),
    surface = Color(0xFF1E293B),
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Color(0xFF334155),
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF475569),
    outlineVariant = Color(0xFF334155)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) LumoDarkColorScheme else LumoLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
