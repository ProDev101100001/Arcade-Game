package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

@Composable
fun GameHeroArtwork(
    gameId: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        when (gameId) {
            "quick_tap" -> HeroQuickTapArtwork()
            "memory_match" -> CardMemoryMatchArtwork()
            "odd_one_out" -> CardOddOneOutArtwork()
            else -> HeroQuickTapArtwork()
        }
    }
}

@Composable
fun GameCardArtwork(
    gameId: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        when (gameId) {
            "quick_tap", "color_challenge" -> CardColorChallengeArtwork()
            "memory_match" -> CardMemoryMatchArtwork()
            "odd_one_out" -> CardOddOneOutArtwork()
            "obstacle_dodge" -> CardObstacleDodgeArtwork()
            "reaction_time" -> TileReactionTimeArtwork()
            "moving_target" -> TileMovingTargetArtwork()
            "speed_math" -> TileSpeedMathArtwork()
            "number_order" -> TileNumberOrderArtwork()
            "memory_sequence" -> TileMemorySequenceArtwork()
            "challenge_hero" -> ChallengeHeroArtwork()
            else -> CardColorChallengeArtwork()
        }
    }
}

// -------------------------------------------------------------
// 1. Quick Tap Hero Artwork (Speed Rings, Energy Pulse, 3D Asset)
// -------------------------------------------------------------

@Composable
fun HeroQuickTapArtwork() {
    val infiniteTransition = rememberInfiniteTransition(label = "quick_tap_hero_anim")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        // High Quality 3D Generated Arcade Graphic
        Image(
            painter = painterResource(id = R.drawable.arcade_quick_tap_hero_1786960879423),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(20.dp))
        )
    }
}

// -------------------------------------------------------------
// 2. Card: Memory Match (Holographic Cards with Star Emblems)
// -------------------------------------------------------------

@Composable
fun CardMemoryMatchArtwork() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.arcade_memory_match_1786960893410),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

// -------------------------------------------------------------
// 3. Card: Odd One Out (Glossy Spheres with Ruby Gem)
// -------------------------------------------------------------

@Composable
fun CardOddOneOutArtwork() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.arcade_odd_one_out_1786960906365),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

// -------------------------------------------------------------
// 4. Card: Obstacle Dodge (Space Mini Rocket & Neon Asteroids)
// -------------------------------------------------------------

@Composable
fun CardObstacleDodgeArtwork() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.arcade_obstacle_dodge_1786960930994),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

// -------------------------------------------------------------
// 5. Card: Color Challenge / Fast Tap (Vibrant Blocks)
// -------------------------------------------------------------

@Composable
fun CardColorChallengeArtwork() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.linearGradient(
                    listOf(Color(0xFF26105A), Color(0xFF160A38))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(76.dp)) {
            val gap = 6.dp.toPx()
            val blockSize = (size.width - gap) / 2f
            val corner = CornerRadius(8.dp.toPx())

            // Top-Left: Coral Red
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFFFF4B4B), Color(0xFFDC2626))),
                topLeft = Offset(0f, 0f),
                size = Size(blockSize, blockSize),
                cornerRadius = corner
            )
            // Top-Right: Electric Blue
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFF38BDF8), Color(0xFF0284C7))),
                topLeft = Offset(blockSize + gap, 0f),
                size = Size(blockSize, blockSize),
                cornerRadius = corner
            )
            // Bottom-Left: Sunny Amber
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFFFDE047), Color(0xFFEAB308))),
                topLeft = Offset(0f, blockSize + gap),
                size = Size(blockSize, blockSize),
                cornerRadius = corner
            )
            // Bottom-Right: Emerald Green
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFF4ADE80), Color(0xFF16A34A))),
                topLeft = Offset(blockSize + gap, blockSize + gap),
                size = Size(blockSize, blockSize),
                cornerRadius = corner
            )
        }
    }
}

// -------------------------------------------------------------
// 6. Challenge Hero Artwork (3D Golden Star Trophy in Bullseye)
// -------------------------------------------------------------

@Composable
fun ChallengeHeroArtwork() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.arcade_challenge_hero_1786960917972),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

// -------------------------------------------------------------
// 7. Horizontal Tile Artworks
// -------------------------------------------------------------

@Composable
fun TileReactionTimeArtwork() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.arcade_reaction_time_1786960942047),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun TileMovingTargetArtwork() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.linearGradient(
                    listOf(Color(0xFFF97316), Color(0xFFEA580C))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(38.dp)) {
            val center = Offset(size.width / 2, size.height / 2)
            drawCircle(Color.White, radius = 16.dp.toPx(), center = center, style = Stroke(width = 3.dp.toPx()))
            drawCircle(Color(0xFFFDE047), radius = 9.dp.toPx(), center = center, style = Stroke(width = 2.5.dp.toPx()))
            drawCircle(Color.White, radius = 4.dp.toPx(), center = center)
        }
    }
}

@Composable
fun TileSpeedMathArtwork() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.linearGradient(
                    listOf(Color(0xFF2563EB), Color(0xFF1D4ED8))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "7 + 3",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
    }
}

@Composable
fun TileNumberOrderArtwork() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.linearGradient(
                    listOf(Color(0xFF8B5CF6), Color(0xFF6D28D9))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "1 · 2",
            color = Color(0xFFFDE047),
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )
    }
}

@Composable
fun TileMemorySequenceArtwork() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.linearGradient(
                    listOf(Color(0xFF1E1B4B), Color(0xFF0F172A))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(34.dp)) {
            val s = 14.dp.toPx()
            val g = 4.dp.toPx()
            drawRoundRect(Color(0xFF4ADE80), topLeft = Offset(0f, 0f), size = Size(s, s), cornerRadius = CornerRadius(3.dp.toPx()))
            drawRoundRect(Color(0xFF38BDF8), topLeft = Offset(s + g, 0f), size = Size(s, s), cornerRadius = CornerRadius(3.dp.toPx()))
            drawRoundRect(Color(0xFFC084FC), topLeft = Offset(0f, s + g), size = Size(s, s), cornerRadius = CornerRadius(3.dp.toPx()))
            drawRoundRect(Color(0xFFF472B6), topLeft = Offset(s + g, s + g), size = Size(s, s), cornerRadius = CornerRadius(3.dp.toPx()))
        }
    }
}
