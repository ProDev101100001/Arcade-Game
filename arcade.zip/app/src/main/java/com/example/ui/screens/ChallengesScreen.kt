package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.audio.LocalSoundManager
import com.example.data.ChallengeEntity
import com.example.ui.LocalStrings
import com.example.ui.components.LumoProgressBar
import com.example.ui.theme.LumoAmber
import com.example.ui.theme.LumoBackground
import com.example.ui.theme.LumoBorder
import com.example.ui.theme.LumoCoral
import com.example.ui.theme.LumoEmerald
import com.example.ui.theme.LumoIris
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoPrimarySurface
import com.example.ui.theme.LumoSuccess
import com.example.ui.theme.LumoSurface
import com.example.ui.theme.LumoTextPrimary
import com.example.ui.theme.LumoTextSecondary
import com.example.ui.theme.LumoTextTertiary
import kotlinx.coroutines.launch

@Composable
fun ChallengesScreen(
    challenges: List<ChallengeEntity>,
    onClaimReward: (String) -> Unit,
    onPlayGame: ((String) -> Unit)? = null
) {
    val strings = LocalStrings.current
    val soundManager = LocalSoundManager.current

    val totalCount = challenges.size.coerceAtLeast(1)
    val completedCount = challenges.count { it.isCompleted }
    val isAllCompleted = completedCount == totalCount
    val totalXpAvailable = challenges.sumOf { it.xpReward }

    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isVisible = true
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(LumoBackground),
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = 10.dp,
            bottom = 90.dp
        ),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // ==========================================
        // 1. Header (Clean, Punchy, Arabic RTL)
        // ==========================================
        item {
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(tween(300)) + slideInVertically(tween(300)) { -15 }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(top = 4.dp)
                ) {
                    Text(
                        text = strings.challengesTitle,
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 28.sp,
                            color = LumoTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = strings.challengesSub,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = LumoTextSecondary
                        )
                    )
                }
            }
        }

        // ==========================================
        // 2. Dominant Large Daily Challenge Hero ("تحدي اليوم")
        // ==========================================
        item {
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(tween(400, delayMillis = 60)) + slideInVertically(tween(400, delayMillis = 60)) { 20 }
            ) {
                LargeDailyChallengeHero(
                    completedCount = completedCount,
                    totalCount = totalCount,
                    xpReward = totalXpAvailable,
                    isAllCompleted = isAllCompleted,
                    onStartOrClaim = {
                        soundManager.playClick()
                        val uncompleted = challenges.find { !it.isCompleted }
                        val readyToClaim = challenges.find { it.isCompleted && !it.isClaimed }
                        if (readyToClaim != null) {
                            onClaimReward(readyToClaim.id)
                        } else if (uncompleted != null) {
                            val targetGame = when (uncompleted.category.lowercase()) {
                                "reflex" -> "quick_tap"
                                "memory" -> "memory_match"
                                "focus" -> "odd_one_out"
                                else -> "quick_tap"
                            }
                            onPlayGame?.invoke(targetGame)
                        } else {
                            onPlayGame?.invoke("quick_tap")
                        }
                    }
                )
            }
        }

        // ==========================================
        // 3. Section: مهام اليوم (Daily Missions)
        // ==========================================
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "مهام اليوم",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = LumoTextPrimary
                    )
                )

                Text(
                    text = "$completedCount من $totalCount مكتملة",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        color = LumoTextSecondary
                    )
                )
            }
        }

        // List of Compact, Simple Mission Cards
        items(challenges) { challenge ->
            val progressFrac = (challenge.currentProgress.toFloat() / challenge.targetValue).coerceIn(0f, 1f)
            val isReadyToClaim = challenge.isCompleted && !challenge.isClaimed
            val targetGame = when (challenge.category.lowercase()) {
                "reflex" -> "quick_tap"
                "memory" -> "memory_match"
                "focus" -> "odd_one_out"
                else -> "quick_tap"
            }

            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(tween(450, delayMillis = 100))
            ) {
                CompactTaskCard(
                    challenge = challenge,
                    progressFrac = progressFrac,
                    isReadyToClaim = isReadyToClaim,
                    onClaim = {
                        soundManager.playSuccess()
                        onClaimReward(challenge.id)
                    },
                    onStart = {
                        soundManager.playClick()
                        onPlayGame?.invoke(targetGame)
                    }
                )
            }
        }
    }
}

// -------------------------------------------------------------------
// Component: Dominant Large Daily Challenge Hero Card
// -------------------------------------------------------------------

@Composable
private fun LargeDailyChallengeHero(
    completedCount: Int,
    totalCount: Int,
    xpReward: Int,
    isAllCompleted: Boolean,
    onStartOrClaim: () -> Unit
) {
    val strings = LocalStrings.current
    val progressFrac = (completedCount.toFloat() / totalCount).coerceIn(0f, 1f)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(22.dp), spotColor = LumoPrimary.copy(alpha = 0.12f)),
        shape = RoundedCornerShape(22.dp),
        color = LumoSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, LumoBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Main Top Row: 3D Challenge Trophy Art + Title + XP Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Visual 3D Target Art Container
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, LumoPrimary.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.arcade_challenge_hero_1786960917972),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Column {
                        Text(
                            text = strings.todayChallenge,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = LumoTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "$totalCount ألعاب سريعة",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = LumoTextSecondary
                            )
                        )
                    }
                }

                // XP Reward Tag
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(LumoPrimarySurface)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.CardGiftcard,
                        contentDescription = null,
                        tint = LumoPrimary,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "+$xpReward ${strings.xp}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = LumoPrimary,
                            fontSize = 13.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Step Progress Dots: ● ● ○
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 1..totalCount) {
                        val isDone = i <= completedCount
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isDone) (if (isAllCompleted) LumoSuccess else LumoPrimary)
                                    else LumoBorder
                                )
                        )
                    }
                }

                Text(
                    text = "$completedCount / $totalCount",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (isAllCompleted) LumoSuccess else LumoPrimary
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Sleek Progress Bar
            LumoProgressBar(
                progress = progressFrac,
                height = 7.dp,
                progressColor = if (isAllCompleted) LumoSuccess else LumoPrimary
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Primary Brand Action Button (#1800AD)
            Button(
                onClick = onStartOrClaim,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("start_daily_challenge_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isAllCompleted) LumoSuccess else LumoPrimary,
                    contentColor = Color.White
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = if (isAllCompleted) Icons.Filled.CheckCircle else Icons.Filled.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (isAllCompleted) strings.completed else strings.startChallenge,
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------------
// Component: Simple, Punchy Daily Mission Task Card
// -------------------------------------------------------------------

@Composable
private fun CompactTaskCard(
    challenge: ChallengeEntity,
    progressFrac: Float,
    isReadyToClaim: Boolean,
    onClaim: () -> Unit,
    onStart: () -> Unit
) {
    val strings = LocalStrings.current
    val scale = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()

    // Determine category icon & accent color
    val (icon, accentColor) = when (challenge.category.lowercase()) {
        "reflex" -> Pair(Icons.Filled.Bolt, LumoCoral)
        "memory" -> Pair(Icons.Filled.Psychology, LumoIris)
        "focus" -> Pair(Icons.Filled.Search, LumoEmerald)
        else -> Pair(Icons.Filled.TrackChanges, LumoPrimary)
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale.value)
            .shadow(2.dp, RoundedCornerShape(16.dp), spotColor = Color.Black.copy(alpha = 0.04f))
            .border(
                1.dp,
                if (isReadyToClaim) LumoAmber.copy(alpha = 0.5f) else LumoBorder,
                RoundedCornerShape(16.dp)
            )
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        scope.launch { scale.animateTo(0.98f, spring(stiffness = Spring.StiffnessMediumLow)) }
                        tryAwaitRelease()
                        scope.launch { scale.animateTo(1f, spring(stiffness = Spring.StiffnessMediumLow)) }
                    },
                    onTap = {
                        if (isReadyToClaim) onClaim()
                        else if (!challenge.isClaimed) onStart()
                    }
                )
            }
            .testTag("challenge_card_${challenge.id}"),
        shape = RoundedCornerShape(16.dp),
        color = LumoSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Task Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    // Category Icon Square
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (challenge.isClaimed) Color(0xFFF1F5F9)
                                else accentColor.copy(alpha = 0.12f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (challenge.isClaimed) Icons.Filled.Check else icon,
                            contentDescription = null,
                            tint = if (challenge.isClaimed) LumoSuccess else accentColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Column {
                        Text(
                            text = challenge.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (challenge.isClaimed) LumoTextSecondary else LumoTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "+${challenge.xpReward} ${strings.xp}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = LumoPrimary
                            )
                        )
                    }
                }

                // Action / Status Pill
                when {
                    challenge.isClaimed -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFECFDF5))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = null,
                                tint = LumoSuccess,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = strings.claimed,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = LumoSuccess
                                )
                            )
                        }
                    }
                    isReadyToClaim -> {
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onClaim() },
                            shape = RoundedCornerShape(8.dp),
                            color = LumoAmber
                        ) {
                            Text(
                                text = "استلم +${challenge.xpReward}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = Color.White
                                ),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                    else -> {
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onStart() }
                                .border(1.dp, LumoPrimary.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
                            shape = RoundedCornerShape(8.dp),
                            color = LumoPrimarySurface
                        ) {
                            Text(
                                text = strings.start,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = LumoPrimary
                                ),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Thin Clean Progress Indicator
            LumoProgressBar(
                progress = progressFrac,
                height = 4.dp,
                progressColor = if (challenge.isCompleted) LumoSuccess else LumoPrimary
            )
        }
    }
}
