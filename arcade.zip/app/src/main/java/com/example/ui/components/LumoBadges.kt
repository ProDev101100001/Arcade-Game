package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LumoAmber
import com.example.ui.theme.LumoAmberDark
import com.example.ui.theme.LumoAmberLight
import com.example.ui.theme.LumoCoral
import com.example.ui.theme.LumoCoralDark
import com.example.ui.theme.LumoCoralLight
import com.example.ui.theme.LumoEmerald
import com.example.ui.theme.LumoEmeraldDark
import com.example.ui.theme.LumoEmeraldLight
import com.example.ui.theme.LumoIris
import com.example.ui.theme.LumoIrisLight
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoPrimaryDark
import com.example.ui.theme.LumoPrimarySurface

@Composable
fun LumoCategoryBadge(
    category: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, icon) = when (category.lowercase()) {
        "reflex" -> Triple(LumoCoralLight, LumoCoralDark, Icons.Rounded.Bolt)
        "memory" -> Triple(LumoIrisLight, LumoIris, Icons.Rounded.Psychology)
        "focus" -> Triple(LumoEmeraldLight, LumoEmeraldDark, Icons.Rounded.Visibility)
        else -> Triple(LumoPrimarySurface, LumoPrimaryDark, Icons.Rounded.Bolt)
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = textColor,
            modifier = Modifier.size(12.dp)
        )
        Text(
            text = category,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            ),
            color = textColor
        )
    }
}

@Composable
fun LumoPillBadge(
    text: String,
    modifier: Modifier = Modifier,
    backgroundColor: Color = LumoPrimarySurface,
    textColor: Color = LumoPrimaryDark,
    icon: ImageVector? = null
) {
    Row(
        modifier = modifier
            .clip(CircleShape)
            .background(backgroundColor)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(14.dp)
            )
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            ),
            color = textColor
        )
    }
}

@Composable
fun LumoLevelBadge(
    level: Int,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(LumoAmberLight)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "LVL $level",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.ExtraBold,
                fontFamily = com.example.ui.theme.NumericFontFamily,
                letterSpacing = 0.5.sp
            ),
            color = LumoAmberDark
        )
    }
}
