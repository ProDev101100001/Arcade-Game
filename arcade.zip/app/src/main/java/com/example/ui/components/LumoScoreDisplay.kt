package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LumoAmber
import com.example.ui.theme.LumoAmberDark
import com.example.ui.theme.LumoAmberLight
import com.example.ui.theme.LumoCoral
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoTextPrimary

@Composable
fun LumoScoreDisplay(
    score: Int,
    modifier: Modifier = Modifier,
    label: String = "SCORE"
) {
    val animatedScore by animateIntAsState(
        targetValue = score,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "score_anim"
    )

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFFF1F3FA))
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp
            ),
            color = Color(0xFF7A7F99)
        )
        Text(
            text = "$animatedScore",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Black,
                fontFamily = com.example.ui.theme.NumericFontFamily,
                fontSize = 20.sp
            ),
            color = LumoTextPrimary
        )
    }
}

@Composable
fun LumoComboBadge(
    combo: Int,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = combo >= 2,
        enter = scaleIn(spring(dampingRatio = 0.5f)) + fadeIn(),
        exit = scaleOut(tween(150)) + fadeOut(),
        modifier = modifier
    ) {
        val scale by animateFloatAsState(
            targetValue = (1f + (combo * 0.05f)).coerceAtMost(1.35f),
            animationSpec = spring(dampingRatio = 0.5f),
            label = "combo_scale"
        )

        Row(
            modifier = Modifier
                .scale(scale)
                .clip(CircleShape)
                .background(
                    Brush.horizontalGradient(
                        listOf(LumoCoral, LumoAmber)
                    )
                )
                .padding(horizontal = 12.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.LocalFireDepartment,
                contentDescription = "Combo",
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = "${combo}x COMBO",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                ),
                color = Color.White
            )
        }
    }
}
