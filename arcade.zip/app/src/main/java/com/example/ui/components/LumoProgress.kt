package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LumoAmber
import com.example.ui.theme.LumoAmberDark
import com.example.ui.theme.LumoBorderSubtle
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoPrimaryLight

@Composable
fun LumoProgressBar(
    progress: Float, // 0f to 1f
    modifier: Modifier = Modifier,
    height: Dp = 8.dp,
    trackColor: Color = LumoBorderSubtle,
    progressGradient: Brush = Brush.horizontalGradient(listOf(LumoPrimary, LumoPrimaryLight)),
    progressColor: Color? = null
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing),
        label = "prog_anim"
    )

    Box(
        modifier = modifier
            .height(height)
            .fillMaxWidth()
            .clip(CircleShape)
            .background(trackColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(animatedProgress)
                .clip(CircleShape)
                .background(
                    if (progressColor != null) Brush.linearGradient(listOf(progressColor, progressColor))
                    else progressGradient
                )
        )
    }
}

@Composable
fun LumoTimerBar(
    fractionRemaining: Float, // 1f to 0f
    modifier: Modifier = Modifier,
    height: Dp = 6.dp,
    timerColor: Color = LumoPrimary
) {
    val animatedFraction by animateFloatAsState(
        targetValue = fractionRemaining.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 100),
        label = "timer_anim"
    )

    val color = when {
        animatedFraction < 0.25f -> Color(0xFFFF5252)
        animatedFraction < 0.5f -> LumoAmber
        else -> timerColor
    }

    Box(
        modifier = modifier
            .height(height)
            .fillMaxWidth()
            .clip(RoundedCornerShape(3.dp))
            .background(Color(0xFFE2E6F2))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(animatedFraction)
                .clip(RoundedCornerShape(3.dp))
                .background(color)
        )
    }
}
