package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppLanguage
import com.example.ui.LocalStrings
import com.example.ui.components.LumoPrimaryButton
import com.example.ui.theme.LumoCoral
import com.example.ui.theme.LumoCoralLight
import com.example.ui.theme.LumoEmerald
import com.example.ui.theme.LumoEmeraldLight
import com.example.ui.theme.LumoIris
import com.example.ui.theme.LumoIrisLight
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoTextPrimary
import com.example.ui.theme.LumoTextSecondary

@Composable
fun OnboardingScreen(
    currentLanguage: AppLanguage = AppLanguage.ARABIC,
    onLanguageSelected: (AppLanguage) -> Unit = {},
    onContinue: () -> Unit
) {
    val strings = LocalStrings.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Center Content - Brand & Game Motifs
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 16.dp)
        ) {
            // Minimal Logo
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(LumoPrimary),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "أ",
                    style = MaterialTheme.typography.displaySmall.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 32.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = strings.appName,
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.5).sp
                ),
                color = LumoTextPrimary
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = strings.tagline,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = FontWeight.Medium,
                    fontSize = 16.sp
                ),
                color = LumoTextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(42.dp))

            // 3 Minimal Game Pillars (Reflex, Memory, Focus)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                GamePillarPreview(
                    title = strings.catReflex,
                    icon = Icons.Filled.Bolt,
                    accentColor = LumoCoral,
                    bgColor = LumoCoralLight
                )
                GamePillarPreview(
                    title = strings.catMemory,
                    icon = Icons.Filled.GridOn,
                    accentColor = LumoIris,
                    bgColor = LumoIrisLight
                )
                GamePillarPreview(
                    title = strings.catFocus,
                    icon = Icons.Filled.Visibility,
                    accentColor = LumoEmerald,
                    bgColor = LumoEmeraldLight
                )
            }
        }

        // Bottom CTA
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            LumoPrimaryButton(
                text = strings.getStarted,
                onClick = onContinue,
                icon = Icons.AutoMirrored.Filled.ArrowForward,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun GamePillarPreview(
    title: String,
    icon: ImageVector,
    accentColor: Color,
    bgColor: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(bgColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
            color = LumoTextSecondary
        )
    }
}
