package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.LocalSoundManager
import com.example.ui.LocalStrings
import com.example.ui.components.LumoPrimaryButton
import com.example.ui.components.LumoSecondaryButton
import com.example.ui.theme.LumoBorder
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoTextPrimary
import com.example.ui.theme.LumoTextSecondary
import com.example.ui.theme.LumoTextTertiary

@Composable
fun AuthScreen(
    onContinueAsGuest: () -> Unit,
    onSignInWithGoogle: () -> Unit,
    onSignInWithApple: () -> Unit,
    onSignInWithEmail: () -> Unit
) {
    val strings = LocalStrings.current
    val soundManager = LocalSoundManager.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Header
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 28.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(LumoPrimary),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "أ",
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = strings.welcome,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.3).sp
                ),
                color = LumoTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = strings.welcomeSub,
                style = MaterialTheme.typography.bodyMedium,
                color = LumoTextSecondary,
                textAlign = TextAlign.Center
            )
        }

        // Actions
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Primary Guest Option
            LumoPrimaryButton(
                text = strings.continueAsGuest,
                onClick = onContinueAsGuest,
                icon = Icons.Filled.PlayArrow,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                HorizontalDivider(modifier = Modifier.weight(1f), color = LumoBorder)
                Text(
                    text = "  ${strings.or}  ",
                    style = MaterialTheme.typography.labelSmall,
                    color = LumoTextTertiary
                )
                HorizontalDivider(modifier = Modifier.weight(1f), color = LumoBorder)
            }

            // Google
            SocialAuthButton(
                text = strings.signInWithGoogle,
                onClick = onSignInWithGoogle
            )

            // Apple
            SocialAuthButton(
                text = strings.signInWithApple,
                onClick = onSignInWithApple
            )

            // Email
            SocialAuthButton(
                text = strings.signInWithEmail,
                icon = Icons.Filled.Email,
                onClick = onSignInWithEmail
            )
        }

        // Legal note
        Text(
            text = strings.termsPrivacy,
            style = MaterialTheme.typography.labelSmall,
            color = LumoTextTertiary,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 8.dp)
        )
    }
}

@Composable
private fun SocialAuthButton(
    text: String,
    onClick: () -> Unit,
    icon: ImageVector? = null
) {
    val soundManager = LocalSoundManager.current

    OutlinedButton(
        onClick = {
            soundManager.playClick()
            onClick()
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, LumoBorder),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = Color.White,
            contentColor = LumoTextPrimary
        )
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                    tint = LumoTextSecondary
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp
                ),
                color = LumoTextPrimary
            )
        }
    }
}
