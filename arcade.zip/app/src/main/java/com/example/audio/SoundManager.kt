package com.example.audio

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.SoundEffectConstants
import androidx.compose.runtime.staticCompositionLocalOf

class SoundManager(private val context: Context) {
    var isSoundEnabled: Boolean = true
    var isHapticsEnabled: Boolean = true

    private val audioManager: AudioManager? by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    fun playTap() {
        if (isSoundEnabled) {
            try {
                audioManager?.playSoundEffect(SoundEffectConstants.CLICK, 0.7f)
            } catch (_: Throwable) {}
        }
        vibrate(10, 80)
    }

    fun playClick() {
        if (isSoundEnabled) {
            try {
                audioManager?.playSoundEffect(SoundEffectConstants.CLICK, 0.5f)
            } catch (_: Throwable) {}
        }
        vibrate(6, 60)
    }

    fun playFlip() {
        if (isSoundEnabled) {
            try {
                audioManager?.playSoundEffect(SoundEffectConstants.NAVIGATION_RIGHT, 0.6f)
            } catch (_: Throwable) {}
        }
        vibrate(8, 70)
    }

    fun playSuccess() {
        if (isSoundEnabled) {
            try {
                audioManager?.playSoundEffect(SoundEffectConstants.NAVIGATION_UP, 0.85f)
            } catch (_: Throwable) {}
        }
        vibrate(30, 180)
    }

    fun playError() {
        if (isSoundEnabled) {
            try {
                audioManager?.playSoundEffect(SoundEffectConstants.NAVIGATION_DOWN, 0.85f)
            } catch (_: Throwable) {}
        }
        vibrate(40, 220)
    }

    fun playCombo(comboCount: Int) {
        if (isSoundEnabled) {
            try {
                audioManager?.playSoundEffect(SoundEffectConstants.NAVIGATION_UP, 0.9f)
            } catch (_: Throwable) {}
        }
        vibrate(15, 120)
    }

    fun playCountdownTick() {
        if (isSoundEnabled) {
            try {
                audioManager?.playSoundEffect(SoundEffectConstants.CLICK, 0.6f)
            } catch (_: Throwable) {}
        }
        vibrate(12, 70)
    }

    fun playCountdownGo() {
        if (isSoundEnabled) {
            try {
                audioManager?.playSoundEffect(SoundEffectConstants.NAVIGATION_UP, 1.0f)
            } catch (_: Throwable) {}
        }
        vibrate(35, 170)
    }

    fun playLevelUp() {
        if (isSoundEnabled) {
            try {
                audioManager?.playSoundEffect(SoundEffectConstants.NAVIGATION_UP, 1.0f)
            } catch (_: Throwable) {}
        }
        vibratePattern(longArrayOf(0, 40, 60, 80))
    }

    private fun vibrate(durationMs: Long, amplitude: Int = 100) {
        if (!isHapticsEnabled) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, amplitude.coerceIn(1, 255)))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {
        }
    }

    private fun vibratePattern(pattern: LongArray) {
        if (!isHapticsEnabled) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, -1)
            }
        } catch (_: Exception) {
        }
    }

    fun release() {
        // No persistent native media handles requiring explicit release
    }
}

val LocalSoundManager = staticCompositionLocalOf<SoundManager> {
    error("SoundManager not provided")
}
