package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import com.example.audio.LocalSoundManager
import com.example.audio.SoundManager
import com.example.games.MemoryMatchGame
import com.example.games.OddOneOutGame
import com.example.games.QuickTapGame
import com.example.ui.MainViewModel
import com.example.ui.ProvideLumoStrings
import com.example.ui.components.LumoBottomNavigationBar
import com.example.ui.components.LumoTab
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ChallengesScreen
import com.example.ui.screens.GamesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.MyApplicationTheme

enum class AppDestination {
    SPLASH,
    ONBOARDING,
    AUTH,
    MAIN_TABS,
    GAME_PLAY
}

class MainActivity : ComponentActivity() {
    private lateinit var soundManager: SoundManager
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        soundManager = SoundManager(this)

        setContent {
            val currentLanguage by viewModel.language

            CompositionLocalProvider(
                LocalSoundManager provides soundManager,
                LocalLayoutDirection provides currentLanguage.layoutDirection
            ) {
                ProvideLumoStrings(language = currentLanguage) {
                    MyApplicationTheme {
                        val profile by viewModel.profileState.collectAsState()
                        val allGamesProgress by viewModel.allGamesProgressState.collectAsState()
                        val challenges by viewModel.challengesState.collectAsState()
                        val achievements by viewModel.achievementsState.collectAsState()

                        // Sync sound/haptic settings to SoundManager
                        profile?.let { p ->
                            soundManager.isSoundEnabled = p.soundEnabled
                            soundManager.isHapticsEnabled = p.hapticEnabled
                        }

                        var currentDestination by remember { mutableStateOf(AppDestination.SPLASH) }
                        var currentTab by remember { mutableStateOf(LumoTab.HOME) }
                        var activeGameId by remember { mutableStateOf<String?>(null) }

                        AnimatedContent(
                            targetState = currentDestination,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "app_dest_transition"
                        ) { destination ->
                            when (destination) {
                                AppDestination.SPLASH -> {
                                    SplashScreen(
                                        onSplashFinished = {
                                            currentDestination = AppDestination.MAIN_TABS
                                        }
                                    )
                                }

                                AppDestination.ONBOARDING -> {
                                    OnboardingScreen(
                                        onContinue = {
                                            currentDestination = AppDestination.AUTH
                                        }
                                    )
                                }

                                AppDestination.AUTH -> {
                                    AuthScreen(
                                        onContinueAsGuest = {
                                            viewModel.completeAuthGuest()
                                            currentDestination = AppDestination.MAIN_TABS
                                        },
                                        onSignInWithGoogle = {
                                            viewModel.completeAuthGuest()
                                            currentDestination = AppDestination.MAIN_TABS
                                        },
                                        onSignInWithApple = {
                                            viewModel.completeAuthGuest()
                                            currentDestination = AppDestination.MAIN_TABS
                                        },
                                        onSignInWithEmail = {
                                            viewModel.completeAuthGuest()
                                            currentDestination = AppDestination.MAIN_TABS
                                        }
                                    )
                                }

                                AppDestination.MAIN_TABS -> {
                                    Scaffold(
                                        modifier = Modifier.fillMaxSize(),
                                        bottomBar = {
                                            LumoBottomNavigationBar(
                                                currentTab = currentTab,
                                                onTabSelected = { currentTab = it }
                                            )
                                        }
                                    ) { innerPadding ->
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .padding(bottom = innerPadding.calculateBottomPadding())
                                        ) {
                                            when (currentTab) {
                                                LumoTab.HOME -> HomeScreen(
                                                    profile = profile,
                                                    allGamesProgress = allGamesProgress,
                                                    onPlayGame = { gameId ->
                                                        activeGameId = gameId
                                                        currentDestination = AppDestination.GAME_PLAY
                                                    },
                                                    onNavigateToChallenges = {
                                                        currentTab = LumoTab.CHALLENGES
                                                    },
                                                    onNavigateToGames = {
                                                        currentTab = LumoTab.GAMES
                                                    }
                                                )

                                                LumoTab.GAMES -> GamesScreen(
                                                    allGamesProgress = allGamesProgress,
                                                    onSelectGame = { gameId ->
                                                        activeGameId = gameId
                                                        currentDestination = AppDestination.GAME_PLAY
                                                    }
                                                )

                                                LumoTab.CHALLENGES -> ChallengesScreen(
                                                    challenges = challenges,
                                                    onClaimReward = { id ->
                                                        viewModel.claimChallenge(id)
                                                    }
                                                )

                                                LumoTab.PROFILE -> ProfileScreen(
                                                    profile = profile,
                                                    achievements = achievements,
                                                    onUpdateUsername = { name ->
                                                        viewModel.updateUsername(name)
                                                    },
                                                    onToggleSound = { enabled ->
                                                        viewModel.toggleSound(enabled)
                                                    },
                                                    onToggleHaptic = { enabled ->
                                                        viewModel.toggleHaptics(enabled)
                                                    },
                                                    onResetData = {
                                                        viewModel.resetAllData()
                                                    },
                                                    onLogOut = {
                                                        currentDestination = AppDestination.AUTH
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                AppDestination.GAME_PLAY -> {
                                    val currentGameProgress = allGamesProgress.find { it.gameId == activeGameId }
                                    val gameLevel = currentGameProgress?.currentLevel ?: 1
                                    val gameBest = currentGameProgress?.highScore ?: 0

                                    when (activeGameId) {
                                        "quick_tap" -> QuickTapGame(
                                            level = gameLevel,
                                            bestScore = gameBest,
                                            onGameFinished = { score, timeMs, level ->
                                                viewModel.onGameFinished("quick_tap", score, timeMs, level)
                                            },
                                            onBack = { currentDestination = AppDestination.MAIN_TABS }
                                        )

                                        "memory_match" -> MemoryMatchGame(
                                            level = gameLevel,
                                            bestScore = gameBest,
                                            onGameFinished = { score, timeMs, level ->
                                                viewModel.onGameFinished("memory_match", score, timeMs, level)
                                            },
                                            onBack = { currentDestination = AppDestination.MAIN_TABS }
                                        )

                                        "odd_one_out" -> OddOneOutGame(
                                            level = gameLevel,
                                            bestScore = gameBest,
                                            onGameFinished = { score, timeMs, level ->
                                                viewModel.onGameFinished("odd_one_out", score, timeMs, level)
                                            },
                                            onBack = { currentDestination = AppDestination.MAIN_TABS }
                                        )

                                        else -> {
                                            currentDestination = AppDestination.MAIN_TABS
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        soundManager.release()
    }
}
