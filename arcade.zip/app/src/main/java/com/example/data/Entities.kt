package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val username: String = "Lumo Player",
    val avatarIndex: Int = 0,
    val playerLevel: Int = 1,
    val currentXp: Int = 0,
    val xpToNextLevel: Int = 200,
    val totalGamesPlayed: Int = 0,
    val currentStreak: Int = 1,
    val bestStreak: Int = 1,
    val lastActiveDate: Long = System.currentTimeMillis(),
    val soundEnabled: Boolean = true,
    val hapticEnabled: Boolean = true,
    val hasCompletedOnboarding: Boolean = false,
    val lastPlayedGameId: String = "quick_tap",
    val reflexSkill: Int = 20,
    val memorySkill: Int = 20,
    val focusSkill: Int = 20,
    val logicSkill: Int = 20,
    val accuracySkill: Int = 20
)

@Entity(tableName = "game_progress")
data class GameProgressEntity(
    @PrimaryKey val gameId: String,
    val gameName: String,
    val category: String,
    val levelUnlocked: Int = 1,
    val currentLevel: Int = 1,
    val highScore: Int = 0,
    val bestTimeMs: Long = 0L,
    val totalPlays: Int = 0,
    val starsEarned: Int = 0,
    val lastPlayedTimestamp: Long = 0L
)

@Entity(tableName = "challenges")
data class ChallengeEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val category: String,
    val targetValue: Int,
    val currentProgress: Int = 0,
    val isCompleted: Boolean = false,
    val isClaimed: Boolean = false,
    val xpReward: Int = 100,
    val isDaily: Boolean = true
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val category: String,
    val currentProgress: Int = 0,
    val maxProgress: Int = 1,
    val isUnlocked: Boolean = false,
    val isClaimed: Boolean = false,
    val unlockedDate: Long? = null,
    val xpReward: Int = 150,
    val iconName: String = "trophy"
)
