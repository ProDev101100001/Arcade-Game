package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Database(
    entities = [
        UserProfileEntity::class,
        GameProgressEntity::class,
        ChallengeEntity::class,
        AchievementEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class LumoDatabase : RoomDatabase() {
    abstract fun userProfileDao(): UserProfileDao
    abstract fun gameProgressDao(): GameProgressDao
    abstract fun challengeDao(): ChallengeDao
    abstract fun achievementDao(): AchievementDao

    companion object {
        @Volatile
        private var INSTANCE: LumoDatabase? = null

        fun getDatabase(context: Context): LumoDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LumoDatabase::class.java,
                    "lumo_mini_games.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Prepopulate default games and achievements
                        CoroutineScope(Dispatchers.IO).launch {
                            val database = getDatabase(context)
                            database.userProfileDao().insertOrUpdate(
                                UserProfileEntity(
                                    id = 1,
                                    username = "ArcadeRider",
                                    avatarIndex = 0,
                                    playerLevel = 1,
                                    currentXp = 45,
                                    xpToNextLevel = 150,
                                    totalGamesPlayed = 0,
                                    currentStreak = 3,
                                    bestStreak = 5,
                                    soundEnabled = true,
                                    hapticEnabled = true,
                                    hasCompletedOnboarding = true,
                                    lastPlayedGameId = "quick_tap",
                                    reflexSkill = 42,
                                    memorySkill = 35,
                                    focusSkill = 50,
                                    logicSkill = 30,
                                    accuracySkill = 45
                                )
                            )
                            database.gameProgressDao().insertAll(
                                listOf(
                                    GameProgressEntity(
                                        gameId = "quick_tap",
                                        gameName = "Quick Tap",
                                        category = "Reflex",
                                        levelUnlocked = 3,
                                        currentLevel = 3,
                                        highScore = 480,
                                        bestTimeMs = 240L,
                                        totalPlays = 12,
                                        starsEarned = 7,
                                        lastPlayedTimestamp = System.currentTimeMillis()
                                    ),
                                    GameProgressEntity(
                                        gameId = "memory_match",
                                        gameName = "Memory Match",
                                        category = "Memory",
                                        levelUnlocked = 2,
                                        currentLevel = 2,
                                        highScore = 650,
                                        bestTimeMs = 14500L,
                                        totalPlays = 8,
                                        starsEarned = 5,
                                        lastPlayedTimestamp = System.currentTimeMillis() - 3600000
                                    ),
                                    GameProgressEntity(
                                        gameId = "odd_one_out",
                                        gameName = "Odd One Out",
                                        category = "Focus",
                                        levelUnlocked = 2,
                                        currentLevel = 2,
                                        highScore = 520,
                                        bestTimeMs = 820L,
                                        totalPlays = 6,
                                        starsEarned = 4,
                                        lastPlayedTimestamp = System.currentTimeMillis() - 7200000
                                    )
                                )
                            )
                            database.challengeDao().insertAll(
                                listOf(
                                    ChallengeEntity(
                                        id = "daily_play_3",
                                        title = "Triple Play",
                                        description = "Play any 3 mini games today",
                                        category = "Daily",
                                        targetValue = 3,
                                        currentProgress = 1,
                                        isCompleted = false,
                                        isClaimed = false,
                                        xpReward = 80,
                                        isDaily = true
                                    ),
                                    ChallengeEntity(
                                        id = "daily_score_reflex",
                                        title = "Speed Lightning",
                                        description = "Score 400+ points in Quick Tap",
                                        category = "Reflex",
                                        targetValue = 400,
                                        currentProgress = 250,
                                        isCompleted = false,
                                        isClaimed = false,
                                        xpReward = 120,
                                        isDaily = true
                                    ),
                                    ChallengeEntity(
                                        id = "daily_odd_streak",
                                        title = "Eagle Eye",
                                        description = "Find 5 odd items in a row in Odd One Out",
                                        category = "Focus",
                                        targetValue = 5,
                                        currentProgress = 3,
                                        isCompleted = false,
                                        isClaimed = false,
                                        xpReward = 100,
                                        isDaily = true
                                    ),
                                    ChallengeEntity(
                                        id = "weekly_marathon",
                                        title = "Arcade Master",
                                        description = "Complete 15 total game rounds this week",
                                        category = "Weekly",
                                        targetValue = 15,
                                        currentProgress = 6,
                                        isCompleted = false,
                                        isClaimed = false,
                                        xpReward = 300,
                                        isDaily = false
                                    )
                                )
                            )
                            database.achievementDao().insertAll(
                                listOf(
                                    AchievementEntity(
                                        id = "first_victory",
                                        title = "First Spark",
                                        description = "Complete your first mini game level",
                                        category = "Milestone",
                                        currentProgress = 1,
                                        maxProgress = 1,
                                        isUnlocked = true,
                                        unlockedDate = System.currentTimeMillis() - 86400000,
                                        xpReward = 50,
                                        iconName = "spark"
                                    ),
                                    AchievementEntity(
                                        id = "speed_demon",
                                        title = "Speed Demon",
                                        description = "React under 250ms in Quick Tap",
                                        category = "Reflex",
                                        currentProgress = 1,
                                        maxProgress = 1,
                                        isUnlocked = true,
                                        unlockedDate = System.currentTimeMillis() - 43200000,
                                        xpReward = 150,
                                        iconName = "bolt"
                                    ),
                                    AchievementEntity(
                                        id = "perfect_memory",
                                        title = "Photographic",
                                        description = "Complete Memory Match without missing a pair",
                                        category = "Memory",
                                        currentProgress = 0,
                                        maxProgress = 1,
                                        isUnlocked = false,
                                        xpReward = 200,
                                        iconName = "brain"
                                    ),
                                    AchievementEntity(
                                        id = "streak_7",
                                        title = "Arcade Devotee",
                                        description = "Maintain a 7-day play streak",
                                        category = "Streak",
                                        currentProgress = 3,
                                        maxProgress = 7,
                                        isUnlocked = false,
                                        xpReward = 250,
                                        iconName = "flame"
                                    ),
                                    AchievementEntity(
                                        id = "games_50",
                                        title = "Century Arcade",
                                        description = "Play 50 mini game sessions",
                                        category = "Plays",
                                        currentProgress = 26,
                                        maxProgress = 50,
                                        isUnlocked = false,
                                        xpReward = 350,
                                        iconName = "trophy"
                                    )
                                )
                            )
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
