package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlin.math.max

data class GameEndSummary(
    val score: Int,
    val bestTimeMs: Long,
    val xpEarned: Int,
    val oldLevel: Int,
    val newLevel: Int,
    val didLevelUp: Boolean,
    val isNewHighScore: Boolean,
    val stars: Int,
    val performanceFeedback: String,
    val nextLevel: Int
)

class LumoRepository(private val database: LumoDatabase) {
    val userProfile: Flow<UserProfileEntity?> = database.userProfileDao().getUserProfile()
    val allGamesProgress: Flow<List<GameProgressEntity>> = database.gameProgressDao().getAllGamesProgress()
    val challenges: Flow<List<ChallengeEntity>> = database.challengeDao().getAllChallenges()
    val achievements: Flow<List<AchievementEntity>> = database.achievementDao().getAllAchievements()

    fun getGameProgress(gameId: String): Flow<GameProgressEntity?> {
        return database.gameProgressDao().getGameProgress(gameId)
    }

    suspend fun updateSettings(soundEnabled: Boolean, hapticEnabled: Boolean) {
        val current = database.userProfileDao().getUserProfileDirect() ?: return
        database.userProfileDao().update(
            current.copy(
                soundEnabled = soundEnabled,
                hapticEnabled = hapticEnabled
            )
        )
    }

    suspend fun updateProfile(username: String, avatarIndex: Int) {
        val current = database.userProfileDao().getUserProfileDirect() ?: return
        database.userProfileDao().update(
            current.copy(
                username = username,
                avatarIndex = avatarIndex
            )
        )
    }

    suspend fun completeOnboarding() {
        val current = database.userProfileDao().getUserProfileDirect() ?: return
        database.userProfileDao().update(current.copy(hasCompletedOnboarding = true))
    }

    suspend fun claimChallengeReward(challengeId: String) {
        val challengesList = database.challengeDao().getAllChallenges().firstOrNull() ?: return
        val challenge = challengesList.find { it.id == challengeId } ?: return
        if (challenge.isCompleted && !challenge.isClaimed) {
            database.challengeDao().insertOrUpdate(challenge.copy(isClaimed = true))
            addXp(challenge.xpReward)
        }
    }

    suspend fun addXp(amount: Int): Pair<Int, Boolean> {
        val profile = database.userProfileDao().getUserProfileDirect() ?: return Pair(1, false)
        var level = profile.playerLevel
        var currentXp = profile.currentXp + amount
        var xpToNext = profile.xpToNextLevel
        var didLevelUp = false

        while (currentXp >= xpToNext) {
            currentXp -= xpToNext
            level += 1
            xpToNext = (xpToNext * 1.25).toInt()
            didLevelUp = true
        }

        database.userProfileDao().update(
            profile.copy(
                playerLevel = level,
                currentXp = currentXp,
                xpToNextLevel = xpToNext
            )
        )
        return Pair(level, didLevelUp)
    }

    suspend fun recordGameFinished(
        gameId: String,
        gameName: String,
        category: String,
        score: Int,
        timeMs: Long,
        levelPlayed: Int,
        accuracyPercent: Int = 100
    ): GameEndSummary {
        val existingGame = database.gameProgressDao().getGameProgressDirect(gameId)
        val prevHighScore = existingGame?.highScore ?: 0
        val isNewHighScore = score > prevHighScore
        val highScore = max(score, prevHighScore)
        val bestTime = if (existingGame == null || existingGame.bestTimeMs == 0L) timeMs else minOf(existingGame.bestTimeMs, timeMs)

        val stars = when {
            score >= 600 -> 3
            score >= 350 -> 2
            else -> 1
        }

        val nextLevel = levelPlayed + 1
        val unlockedLevel = max(existingGame?.levelUnlocked ?: 1, nextLevel)

        val updatedGame = GameProgressEntity(
            gameId = gameId,
            gameName = gameName,
            category = category,
            levelUnlocked = unlockedLevel,
            currentLevel = nextLevel,
            highScore = highScore,
            bestTimeMs = bestTime,
            totalPlays = (existingGame?.totalPlays ?: 0) + 1,
            starsEarned = (existingGame?.starsEarned ?: 0) + stars,
            lastPlayedTimestamp = System.currentTimeMillis()
        )
        database.gameProgressDao().insertOrUpdate(updatedGame)

        // Calculate XP reward
        val baseScoreXp = (score / 5).coerceIn(40, 250)
        val levelBonusXp = levelPlayed * 15
        val earnedXp = baseScoreXp + levelBonusXp

        val profile = database.userProfileDao().getUserProfileDirect() ?: UserProfileEntity()
        val oldLevel = profile.playerLevel
        var currentXp = profile.currentXp + earnedXp
        var level = profile.playerLevel
        var xpToNext = profile.xpToNextLevel
        var didLevelUp = false

        while (currentXp >= xpToNext) {
            currentXp -= xpToNext
            level += 1
            xpToNext = (xpToNext * 1.25).toInt()
            didLevelUp = true
        }

        // Update skills based on category
        val updatedReflex = if (category == "Reflex") (profile.reflexSkill + 3).coerceAtMost(100) else profile.reflexSkill
        val updatedMemory = if (category == "Memory") (profile.memorySkill + 3).coerceAtMost(100) else profile.memorySkill
        val updatedFocus = if (category == "Focus") (profile.focusSkill + 3).coerceAtMost(100) else profile.focusSkill

        database.userProfileDao().insertOrUpdate(
            profile.copy(
                playerLevel = level,
                currentXp = currentXp,
                xpToNextLevel = xpToNext,
                totalGamesPlayed = profile.totalGamesPlayed + 1,
                lastPlayedGameId = gameId,
                reflexSkill = updatedReflex,
                memorySkill = updatedMemory,
                focusSkill = updatedFocus
            )
        )

        // Update active challenges
        val challengesList = database.challengeDao().getAllChallenges().firstOrNull() ?: emptyList()
        challengesList.forEach { ch ->
            if (!ch.isCompleted) {
                var newProg = ch.currentProgress
                if (ch.id == "daily_play_3" || ch.id == "weekly_marathon") {
                    newProg += 1
                } else if (ch.category == category && score >= ch.targetValue) {
                    newProg = ch.targetValue
                }
                val isComp = newProg >= ch.targetValue
                database.challengeDao().insertOrUpdate(ch.copy(currentProgress = newProg, isCompleted = isComp))
            }
        }

        // Relative performance string
        val performanceFeedback = if (isNewHighScore) {
            "New personal high score!"
        } else if (prevHighScore > 0) {
            val ratio = ((score.toFloat() / prevHighScore) * 100).toInt()
            "${ratio}% of your all-time record"
        } else {
            "Great round performance"
        }

        return GameEndSummary(
            score = score,
            bestTimeMs = timeMs,
            xpEarned = earnedXp,
            oldLevel = oldLevel,
            newLevel = level,
            didLevelUp = didLevelUp,
            isNewHighScore = isNewHighScore,
            stars = stars,
            performanceFeedback = performanceFeedback,
            nextLevel = nextLevel
        )
    }

    suspend fun claimAchievementReward(achievementId: String) {
        val achievementsList = database.achievementDao().getAllAchievements().firstOrNull() ?: return
        val ach = achievementsList.find { it.id == achievementId } ?: return
        if (ach.isUnlocked && !ach.isClaimed) {
            database.achievementDao().insertOrUpdate(ach.copy(isClaimed = true))
            addXp(ach.xpReward)
        }
    }

    suspend fun resetAllData() {
        database.userProfileDao().insertOrUpdate(
            UserProfileEntity(
                id = 1,
                username = "Lumo Player",
                avatarIndex = 0,
                playerLevel = 1,
                currentXp = 0,
                xpToNextLevel = 200,
                totalGamesPlayed = 0,
                currentStreak = 1,
                bestStreak = 1,
                soundEnabled = true,
                hapticEnabled = true,
                hasCompletedOnboarding = true,
                lastPlayedGameId = "quick_tap",
                reflexSkill = 20,
                memorySkill = 20,
                focusSkill = 20
            )
        )
        database.gameProgressDao().insertOrUpdate(GameProgressEntity(gameId = "quick_tap", gameName = "Quick Tap", category = "Reflex"))
        database.gameProgressDao().insertOrUpdate(GameProgressEntity(gameId = "memory_match", gameName = "Memory Match", category = "Memory"))
        database.gameProgressDao().insertOrUpdate(GameProgressEntity(gameId = "odd_one_out", gameName = "Odd One Out", category = "Focus"))
    }
}
