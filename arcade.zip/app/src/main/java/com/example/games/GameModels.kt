package com.example.games

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.Strings
import com.example.ui.theme.LumoCoral
import com.example.ui.theme.LumoCoralLight
import com.example.ui.theme.LumoEmerald
import com.example.ui.theme.LumoEmeraldLight
import com.example.ui.theme.LumoIris
import com.example.ui.theme.LumoIrisLight
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoPrimarySurface

enum class GameState {
    INTRO,
    COUNTDOWN,
    PLAYING,
    PAUSED,
    RESULTS
}

data class GameDefinition(
    val id: String,
    val title: String,
    val category: String,
    val subtitle: String,
    val description: String,
    val accentColor: Color,
    val accentLight: Color,
    val iconName: String,
    val maxLevels: Int = 50,
    val instructions: List<String>
) {
    fun getTitle(strings: Strings): String {
        return getLocalizedGameTitle(id, strings)
    }
}

object GameRegistry {
    val QUICK_TAP = GameDefinition(
        id = "quick_tap",
        title = "Quick Tap",
        category = "Reflex",
        subtitle = "Speed & Reaction",
        description = "Hit targets as rapidly as they appear before their timer rings shrink.",
        accentColor = LumoCoral,
        accentLight = LumoCoralLight,
        iconName = "bolt",
        maxLevels = 50,
        instructions = listOf(
            "Tap targets as soon as they emerge on screen.",
            "Faster taps (< 300ms) award bonus multiplier points.",
            "Avoid black bomb targets at higher levels!",
            "Chain consecutive hits without missing to trigger Combos."
        )
    )

    val MEMORY_MATCH = GameDefinition(
        id = "memory_match",
        title = "Memory Match",
        category = "Memory",
        subtitle = "Recall & Pattern",
        description = "Flip cards and find all matching symbol pairs with minimum moves.",
        accentColor = LumoIris,
        accentLight = LumoIrisLight,
        iconName = "brain",
        maxLevels = 50,
        instructions = listOf(
            "Tap any card to reveal the hidden symbol.",
            "Find the matching pair to clear them from the board.",
            "Consecutive matches trigger massive XP combo multipliers!",
            "Complete with fewer moves and faster time for 3 stars."
        )
    )

    val ODD_ONE_OUT = GameDefinition(
        id = "odd_one_out",
        title = "Odd One Out",
        category = "Focus",
        subtitle = "Perception & Speed",
        description = "Spot the subtle difference in the grid of items before the timer expires.",
        accentColor = LumoEmerald,
        accentLight = LumoEmeraldLight,
        iconName = "eye",
        maxLevels = 50,
        instructions = listOf(
            "Scan the grid of items carefully.",
            "Exactly ONE item has a different color, angle, or shape.",
            "Tap the odd item swiftly to score and advance rounds.",
            "Build your streak for lightning XP rewards."
        )
    )

    val allGames = listOf(QUICK_TAP, MEMORY_MATCH, ODD_ONE_OUT)
    val ALL_GAMES = allGames

    fun getGameById(id: String): GameDefinition {
        return allGames.find { it.id == id } ?: QUICK_TAP
    }
}

fun getLocalizedGameTitle(gameId: String, strings: Strings): String {
    return when (gameId) {
        "quick_tap" -> strings.quickTapTitle
        "memory_match" -> strings.memoryMatchTitle
        "odd_one_out" -> strings.oddOneOutTitle
        else -> "Game"
    }
}

fun getGameVisualTokens(gameId: String): Triple<Color, Color, ImageVector> {
    return when (gameId) {
        "quick_tap" -> Triple(LumoCoral, LumoCoralLight, Icons.Filled.Bolt)
        "memory_match" -> Triple(LumoIris, LumoIrisLight, Icons.Filled.Star)
        "odd_one_out" -> Triple(LumoEmerald, LumoEmeraldLight, Icons.Filled.Search)
        else -> Triple(LumoPrimary, LumoPrimarySurface, Icons.Filled.Bolt)
    }
}

fun formatScore(gameId: String, score: Int): String {
    if (score <= 0) return "--"
    return when (gameId) {
        "quick_tap" -> "${score}ms"
        "memory_match" -> "${score}s"
        else -> "$score"
    }
}
