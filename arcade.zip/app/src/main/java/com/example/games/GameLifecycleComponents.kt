package com.example.games

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.LocalSoundManager
import com.example.data.GameEndSummary
import com.example.ui.LocalStrings
import com.example.ui.components.GameHeroArtwork
import com.example.ui.components.LumoCard
import com.example.ui.components.LumoIconButton
import com.example.ui.components.LumoPrimaryButton
import com.example.ui.components.LumoProgressBar
import com.example.ui.components.LumoSecondaryButton
import com.example.ui.components.LumoTextButton
import com.example.ui.theme.LumoAmber
import com.example.ui.theme.LumoAmberDark
import com.example.ui.theme.LumoAmberLight
import com.example.ui.theme.LumoBackground
import com.example.ui.theme.LumoBorder
import com.example.ui.theme.LumoBorderSubtle
import com.example.ui.theme.LumoCoral
import com.example.ui.theme.LumoCoralLight
import com.example.ui.theme.LumoEmerald
import com.example.ui.theme.LumoIris
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoPrimaryDark
import com.example.ui.theme.LumoPrimarySurface
import com.example.ui.theme.LumoSurface
import com.example.ui.theme.LumoTextPrimary
import com.example.ui.theme.LumoTextSecondary
import com.example.ui.theme.LumoTextTertiary
import kotlinx.coroutines.delay

@Composable
fun GameIntroOverlay(
    game: GameDefinition,
    level: Int,
    bestScore: Int,
    onStartGame: () -> Unit,
    onBack: () -> Unit
) {
    val strings = LocalStrings.current
    val (accentColor, bgColor, _) = getGameVisualTokens(game.id)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LumoBackground)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(20.dp)
    ) {
        // Top Back
        LumoIconButton(
            icon = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            onClick = onBack,
            modifier = Modifier.align(Alignment.TopStart),
            testTag = "intro_back_button"
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Artwork Motif
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(bgColor)
                    .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                GameHeroArtwork(gameId = game.id)
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = getLocalizedGameTitle(game.id, strings),
                style = MaterialTheme.typography.displaySmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 26.sp
                ),
                color = LumoTextPrimary
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "${strings.level} $level",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                ),
                color = accentColor
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Score Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = LumoSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, LumoBorderSubtle),
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = strings.bestScore,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                            color = LumoTextTertiary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (bestScore > 0) formatScore(game.id, bestScore) else "--",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            ),
                            color = LumoTextPrimary
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = strings.level,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                            color = LumoTextTertiary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "$level",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            ),
                            color = accentColor
                        )
                    }
                }
            }
        }

        // Play Button
        LumoPrimaryButton(
            text = "${strings.play} (${strings.level} $level)",
            onClick = onStartGame,
            icon = Icons.Filled.PlayArrow,
            backgroundColor = accentColor,
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            testTag = "start_game_button"
        )
    }
}

// -------------------------------------------------------------------
// Polished Countdown: READY -> 3 -> 2 -> 1 -> GO!
// -------------------------------------------------------------------

@Composable
fun CountdownOverlay(
    onFinished: () -> Unit
) {
    val soundManager = LocalSoundManager.current
    val strings = LocalStrings.current
    var step by remember { mutableIntStateOf(0) } // 0: READY, 1: 3, 2: 2, 3: 1, 4: GO!
    var scaleTarget by remember { mutableStateOf(1.25f) }

    val scale by animateFloatAsState(
        targetValue = scaleTarget,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "count_scale"
    )

    LaunchedEffect(Unit) {
        // Step 0: READY
        soundManager.playTap()
        scaleTarget = 1.15f
        delay(400)
        scaleTarget = 1.0f
        delay(300)

        // Steps 1..3: 3, 2, 1
        for (i in 1..3) {
            step = i
            soundManager.playCountdownTick()
            scaleTarget = 1.35f
            delay(120)
            scaleTarget = 1.0f
            delay(580)
        }

        // Step 4: GO!
        step = 4
        soundManager.playCountdownGo()
        scaleTarget = 1.4f
        delay(120)
        scaleTarget = 1.0f
        delay(350)

        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.75f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            val (mainText, subText, mainColor) = when (step) {
                0 -> Triple(strings.ready, "", Color.White)
                1 -> Triple("3", strings.ready, LumoAmber)
                2 -> Triple("2", strings.ready, LumoIris)
                3 -> Triple("1", strings.ready, LumoCoral)
                4 -> Triple(strings.go, "", LumoEmerald)
                else -> Triple(strings.go, "", LumoEmerald)
            }

            Text(
                text = mainText,
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = if (step in 1..3) 84.sp else 54.sp,
                    fontWeight = FontWeight.Black
                ),
                color = mainColor,
                modifier = Modifier.scale(scale)
            )

            if (subText.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = subText,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp
                    ),
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }
    }
}

// -------------------------------------------------------------------
// Standardized Mobile Gameplay HUD
// -------------------------------------------------------------------

@Composable
fun GameHud(
    score: Int,
    level: Int,
    timeText: String? = null,
    fractionRemaining: Float? = null,
    combo: Int,
    accentColor: Color,
    onBack: (() -> Unit)? = null,
    onPause: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current

    // Animated score transition
    val animatedScore by animateIntAsState(
        targetValue = score,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "hud_score"
    )

    // Animated combo pop
    val comboScale = remember { Animatable(1f) }
    LaunchedEffect(combo) {
        if (combo >= 2) {
            comboScale.animateTo(1.25f, spring(stiffness = Spring.StiffnessHigh))
            comboScale.animateTo(1.0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy))
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Side: Back / Pause & Time
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (onBack != null) {
                    LumoIconButton(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        onClick = onBack,
                        size = 38.dp,
                        testTag = "hud_back"
                    )
                }

                // Time Indicator (if applicable)
                if (timeText != null) {
                    val isWarning = (fractionRemaining ?: 1f) < 0.25f
                    Column {
                        Text(
                            text = strings.time,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            ),
                            color = LumoTextTertiary
                        )
                        Text(
                            text = timeText,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            ),
                            color = if (isWarning) LumoCoral else LumoTextPrimary
                        )
                    }
                } else {
                    // Level Pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(accentColor.copy(alpha = 0.12f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${strings.level} $level",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = accentColor,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }

            // Center: Score Indicator
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = strings.score,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    ),
                    color = LumoTextTertiary
                )
                Text(
                    text = String.format(java.util.Locale.US, "%,d", animatedScore),
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = com.example.ui.theme.NumericFontFamily,
                        fontSize = 20.sp
                    ),
                    color = LumoTextPrimary
                )
            }

            // Right: Combo Streak + Pause
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (combo >= 2) {
                    Box(
                        modifier = Modifier
                            .scale(comboScale.value)
                            .shadow(4.dp, RoundedCornerShape(12.dp), spotColor = LumoAmber)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                brush = Brush.linearGradient(
                                    listOf(LumoAmber, LumoAmberDark)
                                )
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.LocalFireDepartment,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "${combo}x",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 12.sp
                                )
                            )
                        }
                    }
                }

                LumoIconButton(
                    icon = Icons.Filled.Pause,
                    contentDescription = strings.pause,
                    onClick = onPause,
                    size = 38.dp,
                    testTag = "hud_pause"
                )
            }
        }

        // Progress bar if fraction provided
        if (fractionRemaining != null) {
            val isWarning = fractionRemaining < 0.25f
            val barColor = if (isWarning) LumoCoral else accentColor
            LumoProgressBar(
                progress = fractionRemaining,
                height = 4.dp,
                progressGradient = Brush.horizontalGradient(listOf(barColor, barColor)),
                trackColor = LumoBorderSubtle
            )
        }
    }
}

// -------------------------------------------------------------------
// Pause Dialog
// -------------------------------------------------------------------

@Composable
fun GamePauseDialog(
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onQuit: () -> Unit
) {
    val strings = LocalStrings.current

    AlertDialog(
        onDismissRequest = onResume,
        title = {
            Text(
                text = strings.pause,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LumoPrimaryButton(
                    text = strings.resume,
                    onClick = onResume,
                    icon = Icons.Filled.PlayArrow,
                    modifier = Modifier.fillMaxWidth()
                )
                LumoSecondaryButton(
                    text = strings.restart,
                    onClick = onRestart,
                    icon = Icons.Filled.Refresh,
                    modifier = Modifier.fillMaxWidth()
                )
                LumoTextButton(
                    text = strings.quit,
                    onClick = onQuit,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {}
    )
}

// -------------------------------------------------------------------
// Celebratory Results Screen
// -------------------------------------------------------------------

@Composable
fun GameResultsScreen(
    summary: GameEndSummary,
    game: GameDefinition,
    onNextLevel: () -> Unit,
    onPlayAgain: () -> Unit,
    onBackToGames: () -> Unit
) {
    val soundManager = LocalSoundManager.current
    val strings = LocalStrings.current
    val (accentColor, _, _) = getGameVisualTokens(game.id)

    // Animated score count-up
    var targetScore by remember { mutableIntStateOf(0) }
    val displayedScore by animateIntAsState(
        targetValue = targetScore,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "result_score"
    )

    LaunchedEffect(Unit) {
        if (summary.didLevelUp) {
            soundManager.playLevelUp()
        } else {
            soundManager.playSuccess()
        }
        delay(150)
        targetScore = summary.score
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LumoBackground)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // New Best Pill or Status
            if (summary.isNewHighScore) {
                Box(
                    modifier = Modifier
                        .shadow(6.dp, RoundedCornerShape(12.dp), spotColor = LumoAmber)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            brush = Brush.linearGradient(
                                listOf(LumoAmber, LumoAmberDark)
                            )
                        )
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.EmojiEvents,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = strings.newBestScore,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        )
                    }
                }
            } else {
                Text(
                    text = strings.greatJob,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    ),
                    color = LumoTextPrimary
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Score Display
            Text(
                text = String.format(java.util.Locale.US, "%,d", displayedScore),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 52.sp,
                    fontFamily = com.example.ui.theme.NumericFontFamily,
                    fontWeight = FontWeight.Black
                ),
                color = LumoTextPrimary
            )

            Text(
                text = strings.score,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                color = LumoTextTertiary
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Clean Results Breakdown Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = LumoSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, LumoBorderSubtle),
                shadowElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.xp,
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp),
                            color = LumoTextSecondary
                        )
                        Text(
                            text = "+${summary.xpEarned} ${strings.xp}",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = LumoPrimary,
                                fontSize = 15.sp
                            )
                        )
                    }

                    HorizontalDivider(color = LumoBorderSubtle)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.level,
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp),
                            color = LumoTextSecondary
                        )
                        Text(
                            text = "${strings.level} ${summary.newLevel}",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = accentColor,
                                fontSize = 15.sp
                            )
                        )
                    }
                }
            }
        }

        // Action Buttons at Bottom
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LumoPrimaryButton(
                text = strings.nextLevel,
                onClick = onNextLevel,
                icon = Icons.Filled.PlayArrow,
                backgroundColor = accentColor,
                modifier = Modifier.fillMaxWidth(),
                testTag = "results_next_level_button"
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LumoSecondaryButton(
                    text = strings.playAgain,
                    onClick = onPlayAgain,
                    icon = Icons.Filled.Refresh,
                    modifier = Modifier.weight(1f),
                    testTag = "results_play_again_button"
                )

                LumoSecondaryButton(
                    text = strings.backToGames,
                    onClick = onBackToGames,
                    modifier = Modifier.weight(1f),
                    testTag = "results_back_games_button"
                )
            }
        }
    }
}
