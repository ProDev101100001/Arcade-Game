package com.example.games

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.LocalSoundManager
import com.example.data.GameEndSummary
import com.example.ui.components.LumoComboBadge
import com.example.ui.components.LumoIconButton
import com.example.ui.components.LumoLevelBadge
import com.example.ui.components.LumoScoreDisplay
import com.example.ui.theme.LumoAmber
import com.example.ui.theme.LumoBackground
import com.example.ui.theme.LumoBorder
import com.example.ui.theme.LumoBorderSubtle
import com.example.ui.theme.LumoCoral
import com.example.ui.theme.LumoCyan
import com.example.ui.theme.LumoEmerald
import com.example.ui.theme.LumoIris
import com.example.ui.theme.LumoIrisLight
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoPrimarySurface
import com.example.ui.theme.LumoRose
import com.example.ui.theme.LumoSurface
import com.example.ui.theme.LumoTextPrimary
import com.example.ui.theme.LumoTextSecondary
import com.example.ui.theme.LumoTextTertiary
import kotlinx.coroutines.delay

data class MemoryCard(
    val id: Int,
    val pairId: Int,
    val icon: ImageVector,
    val tintColor: Color,
    var isFlipped: Boolean = false,
    var isMatched: Boolean = false
)

private val SYMBOLS_PALETTE = listOf(
    Pair(Icons.Default.Bolt, LumoAmber),
    Pair(Icons.Default.Favorite, LumoRose),
    Pair(Icons.Default.Star, LumoAmber),
    Pair(Icons.Default.Diamond, LumoCyan),
    Pair(Icons.Default.LocalFireDepartment, LumoCoral),
    Pair(Icons.Default.DarkMode, LumoIris),
    Pair(Icons.Default.Shield, LumoEmerald),
    Pair(Icons.Default.EmojiEvents, LumoAmber)
)

@Composable
fun MemoryMatchGame(
    level: Int,
    bestScore: Int,
    onGameFinished: (score: Int, timeMs: Long, level: Int) -> GameEndSummary,
    onBack: () -> Unit
) {
    val soundManager = LocalSoundManager.current
    var gameState by remember { mutableStateOf(GameState.INTRO) }
    var score by remember { mutableIntStateOf(0) }
    var moves by remember { mutableIntStateOf(0) }
    var combo by remember { mutableIntStateOf(0) }
    var maxCombo by remember { mutableIntStateOf(0) }
    var gameStartTime by remember { mutableLongStateOf(0L) }
    var roundSummary by remember { mutableStateOf<GameEndSummary?>(null) }

    val cards = remember { mutableStateListOf<MemoryCard>() }
    var flippedCards by remember { mutableStateOf<List<MemoryCard>>(emptyList()) }
    var isProcessingMatch by remember { mutableStateOf(false) }

    val pairCount = when {
        level <= 1 -> 2 // 2x2 = 4 cards
        level == 2 -> 3 // 2x3 = 6 cards
        level == 3 -> 4 // 2x4 = 8 cards
        level == 4 -> 6 // 3x4 = 12 cards
        else -> 8       // 4x4 = 16 cards
    }

    val gridColumns = when {
        pairCount <= 2 -> 2
        pairCount <= 4 -> 2
        pairCount <= 6 -> 3
        else -> 4
    }

    fun setupBoard() {
        cards.clear()
        val selectedSymbols = SYMBOLS_PALETTE.take(pairCount)
        val deck = mutableListOf<MemoryCard>()

        selectedSymbols.forEachIndexed { index, pair ->
            deck.add(MemoryCard(id = index * 2, pairId = index, icon = pair.first, tintColor = pair.second))
            deck.add(MemoryCard(id = index * 2 + 1, pairId = index, icon = pair.first, tintColor = pair.second))
        }

        deck.shuffle()
        cards.addAll(deck)
    }

    fun triggerStart() {
        gameState = GameState.COUNTDOWN
    }

    fun beginPlaying() {
        setupBoard()
        gameState = GameState.PLAYING
        score = 0
        moves = 0
        combo = 0
        maxCombo = 0
        flippedCards = emptyList()
        isProcessingMatch = false
        gameStartTime = System.currentTimeMillis()
    }

    // Check card selection
    fun onCardClicked(card: MemoryCard) {
        if (isProcessingMatch || card.isMatched || card.isFlipped) return

        soundManager.playFlip()
        val index = cards.indexOfFirst { it.id == card.id }
        if (index != -1) {
            cards[index] = cards[index].copy(isFlipped = true)
        }

        val updatedFlipped = flippedCards + card
        flippedCards = updatedFlipped

        if (updatedFlipped.size == 2) {
            moves++
            isProcessingMatch = true
            val first = updatedFlipped[0]
            val second = updatedFlipped[1]

            if (first.pairId == second.pairId) {
                // MATCH!
                combo++
                if (combo > maxCombo) maxCombo = combo
                val points = 120 + (combo * 30)
                score += points

                if (combo >= 2) {
                    soundManager.playCombo(combo)
                } else {
                    soundManager.playSuccess()
                }

                val i1 = cards.indexOfFirst { it.id == first.id }
                val i2 = cards.indexOfFirst { it.id == second.id }
                if (i1 != -1) cards[i1] = cards[i1].copy(isMatched = true)
                if (i2 != -1) cards[i2] = cards[i2].copy(isMatched = true)

                flippedCards = emptyList()
                isProcessingMatch = false

                // Check victory condition
                if (cards.all { it.isMatched }) {
                    val durationMs = System.currentTimeMillis() - gameStartTime
                    // Move efficiency bonus
                    val perfectMoves = pairCount
                    val moveBonus = ((perfectMoves.toFloat() / moves.coerceAtLeast(1)) * 200).toInt()
                    val totalFinalScore = score + moveBonus
                    val result = onGameFinished(totalFinalScore, durationMs, level)
                    roundSummary = result
                    gameState = GameState.RESULTS
                }
            } else {
                // MISMATCH
                combo = 0
                soundManager.playError()
            }
        }
    }

    // Auto-flip back after mismatch
    LaunchedEffect(flippedCards) {
        if (flippedCards.size == 2 && isProcessingMatch) {
            val first = flippedCards[0]
            val second = flippedCards[1]
            if (first.pairId != second.pairId) {
                delay(750)
                val i1 = cards.indexOfFirst { it.id == first.id }
                val i2 = cards.indexOfFirst { it.id == second.id }
                if (i1 != -1) cards[i1] = cards[i1].copy(isFlipped = false)
                if (i2 != -1) cards[i2] = cards[i2].copy(isFlipped = false)
                flippedCards = emptyList()
                isProcessingMatch = false
            }
        }
    }

    when (gameState) {
        GameState.INTRO -> {
            GameIntroOverlay(
                game = GameRegistry.MEMORY_MATCH,
                level = level,
                bestScore = bestScore,
                onStartGame = { triggerStart() },
                onBack = onBack
            )
        }

        GameState.COUNTDOWN -> {
            CountdownOverlay(onFinished = { beginPlaying() })
        }

        GameState.PLAYING -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(LumoBackground)
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    // Top Header Bar
                    val matchedPairsCount = cards.count { it.isMatched } / 2
                    val pairsFraction = (matchedPairsCount.toFloat() / pairCount).coerceIn(0f, 1f)

                    GameHud(
                        score = score,
                        level = level,
                        timeText = "$moves ${if (com.example.ui.LocalStrings.current.lang == com.example.ui.AppLanguage.ARABIC) "حركات" else "moves"}",
                        fractionRemaining = pairsFraction,
                        combo = combo,
                        accentColor = LumoIris,
                        onBack = onBack,
                        onPause = { gameState = GameState.PAUSED }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Cards Grid
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(gridColumns),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp)
                                .testTag("memory_grid")
                        ) {
                            items(cards, key = { it.id }) { card ->
                                MemoryCardItem(
                                    card = card,
                                    onClick = { onCardClicked(card) }
                                )
                            }
                        }
                    }
                }
            }
        }

        GameState.RESULTS -> {
            roundSummary?.let { sum ->
                GameResultsScreen(
                    summary = sum,
                    game = GameRegistry.MEMORY_MATCH,
                    onNextLevel = { triggerStart() },
                    onPlayAgain = { triggerStart() },
                    onBackToGames = onBack
                )
            }
        }

        GameState.PAUSED -> {
            GamePauseDialog(
                onResume = { gameState = GameState.PLAYING },
                onRestart = { triggerStart() },
                onQuit = onBack
            )
        }
    }
}

@Composable
fun MemoryCardItem(
    card: MemoryCard,
    onClick: () -> Unit
) {
    val rotation by animateFloatAsState(
        targetValue = if (card.isFlipped || card.isMatched) 180f else 0f,
        animationSpec = tween(350, easing = FastOutSlowInEasing),
        label = "card_flip"
    )

    Box(
        modifier = Modifier
            .aspectRatio(0.85f)
            .graphicsLayer {
                rotationY = rotation
                cameraDistance = 12 * density
            }
            .clip(RoundedCornerShape(18.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                onClick()
            }
            .testTag("memory_card_${card.id}")
    ) {
        if (rotation <= 90f) {
            // Front (Hidden)
            Surface(
                modifier = Modifier.fillMaxSize(),
                shape = RoundedCornerShape(18.dp),
                color = LumoSurface,
                border = BorderStroke(1.5.dp, LumoBorderSubtle),
                shadowElevation = 3.dp
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFFFFFFFF), Color(0xFFF0F2FA))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        modifier = Modifier.size(36.dp),
                        shape = CircleShape,
                        color = LumoIrisLight
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = LumoIris,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        } else {
            // Back (Revealed symbol)
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { rotationY = 180f },
                shape = RoundedCornerShape(18.dp),
                color = if (card.isMatched) Color(0xFFE8F5E9) else LumoSurface,
                border = BorderStroke(
                    2.dp,
                    if (card.isMatched) Color(0xFF4CAF50) else card.tintColor.copy(alpha = 0.5f)
                ),
                shadowElevation = 4.dp
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = card.icon,
                        contentDescription = null,
                        tint = card.tintColor,
                        modifier = Modifier.size(38.dp)
                    )
                }
            }
        }
    }
}
