package com.example.games

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Hexagon
import androidx.compose.material.icons.filled.Square
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.LocalSoundManager
import com.example.data.GameEndSummary
import com.example.ui.components.LumoComboBadge
import com.example.ui.components.LumoIconButton
import com.example.ui.components.LumoLevelBadge
import com.example.ui.components.LumoScoreDisplay
import com.example.ui.components.LumoTimerBar
import com.example.ui.theme.LumoBackground
import com.example.ui.theme.LumoBorder
import com.example.ui.theme.LumoBorderSubtle
import com.example.ui.theme.LumoCoral
import com.example.ui.theme.LumoCyan
import com.example.ui.theme.LumoEmerald
import com.example.ui.theme.LumoEmeraldDark
import com.example.ui.theme.LumoEmeraldLight
import com.example.ui.theme.LumoIris
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.LumoRose
import com.example.ui.theme.LumoSurface
import com.example.ui.theme.LumoTextPrimary
import com.example.ui.theme.LumoTextSecondary
import com.example.ui.theme.LumoTextTertiary
import kotlinx.coroutines.delay
import kotlin.random.Random

data class OddItem(
    val id: Int,
    val isOdd: Boolean,
    val icon: ImageVector,
    val rotationDeg: Float,
    val tintColor: Color
)

@Composable
fun OddOneOutGame(
    level: Int,
    bestScore: Int,
    onGameFinished: (score: Int, timeMs: Long, level: Int) -> GameEndSummary,
    onBack: () -> Unit
) {
    val soundManager = LocalSoundManager.current
    var gameState by remember { mutableStateOf(GameState.INTRO) }
    var currentRound by remember { mutableIntStateOf(1) }
    val totalRounds = 8
    var score by remember { mutableIntStateOf(0) }
    var combo by remember { mutableIntStateOf(0) }
    var maxCombo by remember { mutableIntStateOf(0) }
    var roundTimeRemainingMs by remember { mutableLongStateOf(4000L) }
    val roundDurationMs = (4500L - (level * 80L)).coerceAtLeast(2200L)
    var gameStartTime by remember { mutableLongStateOf(0L) }
    var roundSummary by remember { mutableStateOf<GameEndSummary?>(null) }

    val itemsList = remember { mutableStateListOf<OddItem>() }
    var oddIndex by remember { mutableIntStateOf(0) }

    val gridSize = when {
        level <= 1 -> if (currentRound <= 4) 2 else 3
        level <= 3 -> if (currentRound <= 2) 2 else 3
        else -> if (currentRound <= 3) 3 else 4
    }

    fun generateRoundItems() {
        itemsList.clear()
        val totalItems = gridSize * gridSize
        oddIndex = Random.nextInt(totalItems)

        val baseIcons = listOf(
            Icons.Default.Hexagon,
            Icons.Default.Diamond,
            Icons.Default.Star,
            Icons.Default.Favorite,
            Icons.Default.Circle,
            Icons.Default.Square
        )
        val basePalette = listOf(LumoEmerald, LumoPrimary, LumoCoral, LumoCyan, LumoRose, LumoIris)

        val commonIcon = baseIcons.random()
        val commonColor = basePalette.random()

        // Choose difference mode: 0 = Rotation, 1 = Color Shift, 2 = Icon difference
        val diffMode = Random.nextInt(3)

        for (i in 0 until totalItems) {
            val isOdd = (i == oddIndex)
            val icon = if (isOdd && diffMode == 2) baseIcons.filter { it != commonIcon }.random() else commonIcon
            val rotation = if (isOdd && diffMode == 0) 180f else 0f
            val color = if (isOdd && diffMode == 1) {
                // Subtle delta shift
                val delta = (0.28f - (level * 0.02f)).coerceAtLeast(0.12f)
                commonColor.copy(alpha = (1f - delta))
            } else commonColor

            itemsList.add(OddItem(id = i, isOdd = isOdd, icon = icon, rotationDeg = rotation, tintColor = color))
        }
        roundTimeRemainingMs = roundDurationMs
    }

    fun triggerStart() {
        gameState = GameState.COUNTDOWN
    }

    fun beginPlaying() {
        gameState = GameState.PLAYING
        score = 0
        currentRound = 1
        combo = 0
        maxCombo = 0
        gameStartTime = System.currentTimeMillis()
        generateRoundItems()
    }

    // Round countdown ticker
    LaunchedEffect(gameState, currentRound) {
        if (gameState == GameState.PLAYING) {
            val tickInterval = 50L
            while (roundTimeRemainingMs > 0 && gameState == GameState.PLAYING) {
                delay(tickInterval)
                roundTimeRemainingMs -= tickInterval
            }
            if (roundTimeRemainingMs <= 0 && gameState == GameState.PLAYING) {
                // Time up for round -> advance with penalty
                soundManager.playError()
                combo = 0
                if (currentRound < totalRounds) {
                    currentRound++
                    generateRoundItems()
                } else {
                    val durationMs = System.currentTimeMillis() - gameStartTime
                    val result = onGameFinished(score, durationMs, level)
                    roundSummary = result
                    gameState = GameState.RESULTS
                }
            }
        }
    }

    fun onItemClick(item: OddItem) {
        if (gameState != GameState.PLAYING) return

        if (item.isOdd) {
            // Correct!
            combo++
            if (combo > maxCombo) maxCombo = combo
            val timeBonus = ((roundTimeRemainingMs.toFloat() / roundDurationMs) * 100).toInt()
            val points = 100 + timeBonus + (combo * 20)
            score += points

            if (combo >= 2) {
                soundManager.playCombo(combo)
            } else {
                soundManager.playSuccess()
            }

            if (currentRound < totalRounds) {
                currentRound++
                generateRoundItems()
            } else {
                val durationMs = System.currentTimeMillis() - gameStartTime
                val result = onGameFinished(score, durationMs, level)
                roundSummary = result
                gameState = GameState.RESULTS
            }
        } else {
            // Wrong tap
            soundManager.playError()
            combo = 0
            score = (score - 30).coerceAtLeast(0)
        }
    }

    when (gameState) {
        GameState.INTRO -> {
            GameIntroOverlay(
                game = GameRegistry.ODD_ONE_OUT,
                level = level,
                bestScore = bestScore,
                onStartGame = { triggerStart() },
                onBack = onBack
            )
        }

        GameState.COUNTDOWN -> {
            CountdownOverlay(onFinished = { beginPlaying() })
        }

        GameState.PLAYING -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(LumoBackground)
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    // Top Bar
                    val timerFraction = (roundTimeRemainingMs.toFloat() / roundDurationMs).coerceIn(0f, 1f)
                    val secondsRemaining = String.format("%.1fs", roundTimeRemainingMs / 1000f)

                    GameHud(
                        score = score,
                        level = level,
                        timeText = secondsRemaining,
                        fractionRemaining = timerFraction,
                        combo = combo,
                        accentColor = LumoEmerald,
                        onBack = onBack,
                        onPause = { gameState = GameState.PAUSED }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Round counter
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${if (com.example.ui.LocalStrings.current.lang == com.example.ui.AppLanguage.ARABIC) "الجولة" else "Round"} $currentRound / $totalRounds",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = LumoEmeraldDark
                        )
                        Text(
                            text = if (com.example.ui.LocalStrings.current.lang == com.example.ui.AppLanguage.ARABIC) "المستوى $level" else "Level $level",
                            style = MaterialTheme.typography.bodySmall,
                            color = LumoTextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Grid Arena
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(gridSize),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp)
                                .testTag("odd_grid")
                        ) {
                            itemsIndexed(itemsList) { _, item ->
                                Surface(
                                    modifier = Modifier
                                        .aspectRatio(1f)
                                        .clip(RoundedCornerShape(20.dp))
                                        .clickable(
                                            interactionSource = remember { MutableInteractionSource() },
                                            indication = null
                                        ) {
                                            onItemClick(item)
                                        }
                                        .testTag("odd_item_${item.id}"),
                                    shape = RoundedCornerShape(20.dp),
                                    color = LumoSurface,
                                    border = BorderStroke(1.5.dp, LumoBorderSubtle),
                                    shadowElevation = 3.dp
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = item.icon,
                                            contentDescription = null,
                                            tint = item.tintColor,
                                            modifier = Modifier
                                                .size(if (gridSize == 2) 54.dp else if (gridSize == 3) 42.dp else 32.dp)
                                                .rotate(item.rotationDeg)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        GameState.RESULTS -> {
            roundSummary?.let { sum ->
                GameResultsScreen(
                    summary = sum,
                    game = GameRegistry.ODD_ONE_OUT,
                    onNextLevel = { triggerStart() },
                    onPlayAgain = { triggerStart() },
                    onBackToGames = onBack
                )
            }
        }

        GameState.PAUSED -> {
            GamePauseDialog(
                onResume = { gameState = GameState.PLAYING },
                onRestart = { triggerStart() },
                onQuit = onBack
            )
        }
    }
}
