package com.example.games

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.audio.LocalSoundManager
import com.example.data.GameEndSummary
import com.example.ui.LocalStrings
import com.example.ui.theme.LumoAmber
import com.example.ui.theme.LumoAmberDark
import com.example.ui.theme.LumoBackground
import com.example.ui.theme.LumoCoral
import com.example.ui.theme.LumoEmerald
import com.example.ui.theme.LumoPrimary
import com.example.ui.theme.NumericFontFamily
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

// -----------------------------------------------------------------------------
// GAME STATE MODELS
// -----------------------------------------------------------------------------

data class QuickTarget(
    val id: Long,
    val xFraction: Float,
    val yFraction: Float,
    val spawnTime: Long,
    val lifetimeMs: Long,
    val isGolden: Boolean = false,
    val isTrap: Boolean = false
)

data class TapFloatingFeedback(
    val id: Long,
    val text: String,
    val xFraction: Float,
    val yFraction: Float,
    val color: Color,
    val isPenalty: Boolean = false
)

data class TapParticleSpark(
    val x: Float,
    val y: Float,
    val vx: Float,
    val vy: Float,
    val color: Color,
    val size: Float,
    val alpha: Float
)

// -----------------------------------------------------------------------------
// MAIN GAME SCREEN (GAME-FIRST, PURE ARCADE)
// -----------------------------------------------------------------------------

@Composable
fun QuickTapGame(
    level: Int,
    bestScore: Int,
    onGameFinished: (score: Int, timeMs: Long, level: Int) -> GameEndSummary,
    onBack: () -> Unit
) {
    val soundManager = LocalSoundManager.current
    val strings = LocalStrings.current
    val scope = rememberCoroutineScope()

    var gameState by remember { mutableStateOf(GameState.COUNTDOWN) }
    var score by remember { mutableIntStateOf(0) }
    var combo by remember { mutableIntStateOf(0) }
    var maxCombo by remember { mutableIntStateOf(0) }
    var targetsHit by remember { mutableIntStateOf(0) }
    var totalReactionTimeMs by remember { mutableLongStateOf(0L) }
    var reactionCount by remember { mutableIntStateOf(0) }
    var roundSummary by remember { mutableStateOf<GameEndSummary?>(null) }

    // Game Duration (45 seconds round)
    val totalGameDurationSeconds = 45
    var secondsRemaining by remember { mutableIntStateOf(totalGameDurationSeconds) }

    // Screen Shake & Flash Animators
    val shakeOffset = remember { Animatable(0f) }
    val flashAlpha = remember { Animatable(0f) }

    // Targets and Feedback State
    val currentTargets = remember { mutableStateListOf<QuickTarget>() }
    val feedbackList = remember { mutableStateListOf<TapFloatingFeedback>() }

    // Difficulty tuning
    val targetLifetimeMs = (1100L - (level * 25L)).coerceAtLeast(550L)
    val trapChance = when {
        level <= 1 -> 0.0f
        level <= 3 -> 0.12f
        level <= 6 -> 0.18f
        else -> 0.24f
    }
    val goldenChance = 0.20f

    fun startNewGame() {
        score = 0
        combo = 0
        maxCombo = 0
        targetsHit = 0
        reactionCount = 0
        totalReactionTimeMs = 0L
        secondsRemaining = totalGameDurationSeconds
        currentTargets.clear()
        feedbackList.clear()
        gameState = GameState.COUNTDOWN
    }

    fun spawnNextTarget() {
        val now = System.currentTimeMillis()
        val isTrap = Random.nextFloat() < trapChance
        val isGolden = !isTrap && Random.nextFloat() < goldenChance

        val newTarget = QuickTarget(
            id = now + Random.nextLong(1000),
            xFraction = Random.nextFloat() * 0.70f + 0.15f,
            yFraction = Random.nextFloat() * 0.65f + 0.18f,
            spawnTime = now,
            lifetimeMs = targetLifetimeMs,
            isGolden = isGolden,
            isTrap = isTrap
        )
        currentTargets.clear()
        currentTargets.add(newTarget)
    }

    fun handleTrapHit(target: QuickTarget) {
        soundManager.playError()
        score = (score - 150).coerceAtLeast(0)
        combo = 0

        feedbackList.add(
            TapFloatingFeedback(
                id = System.currentTimeMillis(),
                text = strings.trapHit,
                xFraction = target.xFraction,
                yFraction = target.yFraction,
                color = LumoCoral,
                isPenalty = true
            )
        )

        // Rapid Screen Shake
        scope.launch {
            for (i in 0..3) {
                val offset = if (i % 2 == 0) 12f else -12f
                shakeOffset.animateTo(offset, tween(35, easing = LinearEasing))
            }
            shakeOffset.animateTo(0f, tween(35))
        }

        // Red Hazard Screen Flash
        scope.launch {
            flashAlpha.snapTo(0.35f)
            flashAlpha.animateTo(0f, tween(250, easing = LinearEasing))
        }

        currentTargets.remove(target)
        // Spawn immediately
        scope.launch {
            delay(120)
            if (gameState == GameState.PLAYING) {
                spawnNextTarget()
            }
        }
    }

    fun handleTargetHit(target: QuickTarget, reactMs: Long) {
        targetsHit++
        reactionCount++
        totalReactionTimeMs += reactMs
        combo++
        if (combo > maxCombo) maxCombo = combo

        val basePoints = when {
            target.isGolden -> 250
            reactMs < 280 -> 150
            reactMs < 450 -> 100
            else -> 60
        }
        val comboBonus = (combo * 15)
        val earned = basePoints + comboBonus
        score += earned

        val feedbackText = when {
            target.isGolden -> strings.goldenHit
            reactMs < 280 -> strings.perfectHit
            else -> "+$earned"
        }

        val feedbackColor = when {
            target.isGolden -> LumoAmber
            combo >= 5 -> Color(0xFF38BDF8)
            reactMs < 280 -> LumoEmerald
            else -> Color.White
        }

        feedbackList.add(
            TapFloatingFeedback(
                id = System.currentTimeMillis(),
                text = feedbackText,
                xFraction = target.xFraction,
                yFraction = target.yFraction,
                color = feedbackColor,
                isPenalty = false
            )
        )

        if (target.isGolden) {
            soundManager.playLevelUp()
        } else if (combo >= 3) {
            soundManager.playCombo(combo)
        } else {
            soundManager.playTap()
        }

        currentTargets.remove(target)

        // Spawn next target rapidly
        scope.launch {
            delay(100)
            if (gameState == GameState.PLAYING) {
                spawnNextTarget()
            }
        }
    }

    // Main Timer Loop (Seconds Countdown)
    LaunchedEffect(gameState) {
        if (gameState == GameState.PLAYING) {
            if (currentTargets.isEmpty()) {
                spawnNextTarget()
            }
            while (secondsRemaining > 0 && gameState == GameState.PLAYING) {
                delay(1000)
                secondsRemaining--
            }

            if (secondsRemaining <= 0 && gameState == GameState.PLAYING) {
                soundManager.playSuccess()
                val avgReactionMs = if (reactionCount > 0) totalReactionTimeMs / reactionCount else 350L
                val summary = onGameFinished(score, avgReactionMs, level)
                roundSummary = summary
                gameState = GameState.RESULTS
            }
        }
    }

    // Target Auto-Expiry & Spawner Loop
    LaunchedEffect(gameState) {
        if (gameState == GameState.PLAYING) {
            while (gameState == GameState.PLAYING) {
                val now = System.currentTimeMillis()
                val expired = currentTargets.filter { now - it.spawnTime > it.lifetimeMs }
                if (expired.isNotEmpty()) {
                    expired.forEach { exp ->
                        currentTargets.remove(exp)
                        if (!exp.isTrap) {
                            combo = 0 // Reset streak on miss
                        }
                    }
                    if (currentTargets.isEmpty() && gameState == GameState.PLAYING) {
                        spawnNextTarget()
                    }
                }

                // Remove old feedback popups
                feedbackList.removeAll { now - it.id > 850 }
                delay(30)
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset { IntOffset(shakeOffset.value.roundToInt(), 0) }
                .background(LumoBackground)
        ) {
            // -------------------------------------------------------------
            // SUBTLE ARCADE BACKGROUND ARTWORK
            // -------------------------------------------------------------
            Image(
                painter = painterResource(id = R.drawable.arcade_quicktap_bg_1786962052681),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(0.28f)
            )

            // Deep Brand Gradient
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.verticalGradient(
                            listOf(
                                Color(0xFF09041A).copy(alpha = 0.85f),
                                Color(0xFF1800AD).copy(alpha = 0.25f),
                                Color(0xFF070314).copy(alpha = 0.95f)
                            )
                        )
                    )
            )

            // Live Subtle Floating Ambient Spark Particles
            AmbientArcadeCanvas()

            // Red Screen Flash on Hazard Penalty
            if (flashAlpha.value > 0.01f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFFDC2626).copy(alpha = flashAlpha.value))
                )
            }

            // -------------------------------------------------------------
            // GAME STATES
            // -------------------------------------------------------------
            when (gameState) {
                GameState.COUNTDOWN -> {
                    ArcadeCountdownOverlay(
                        onFinished = {
                            gameState = GameState.PLAYING
                            if (currentTargets.isEmpty()) {
                                spawnNextTarget()
                            }
                        }
                    )
                }

                GameState.PLAYING -> {
                    // FULL SCREEN GAMEPLAY
                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxSize()
                            .windowInsetsPadding(WindowInsets.statusBars)
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .testTag("quick_tap_gameplay_screen")
                    ) {
                        val arenaWidthPx = constraints.maxWidth.toFloat()
                        val arenaHeightPx = constraints.maxHeight.toFloat()

                        // -------------------------------------------------
                        // TOP FIXED HUD (CLEAN, GAME-FIRST)
                        // -------------------------------------------------
                        ArcadeGameHud(
                            score = score,
                            secondsRemaining = secondsRemaining,
                            combo = combo,
                            onPause = { gameState = GameState.PAUSED },
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopCenter)
                                .padding(horizontal = 20.dp, vertical = 12.dp)
                        )

                        // -------------------------------------------------
                        // ACTIVE GAME OBJECTS (Single Target / Trap)
                        // -------------------------------------------------
                        currentTargets.forEach { target ->
                            val targetSizeDp = if (target.isGolden) 80.dp else if (target.isTrap) 76.dp else 72.dp
                            val xPos = (target.xFraction * (arenaWidthPx - 160f)).coerceAtLeast(20f)
                            val yPos = (target.yFraction * (arenaHeightPx - 200f)).coerceAtLeast(100f)

                            val age = (System.currentTimeMillis() - target.spawnTime).coerceAtLeast(0L)
                            val fractionRemaining = (1f - (age.toFloat() / target.lifetimeMs)).coerceIn(0f, 1f)

                            Box(
                                modifier = Modifier
                                    .offset { IntOffset(xPos.roundToInt(), yPos.roundToInt()) }
                                    .size(targetSizeDp)
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null
                                    ) {
                                        val reactMs = (System.currentTimeMillis() - target.spawnTime).coerceAtLeast(50L)
                                        if (target.isTrap) {
                                            handleTrapHit(target)
                                        } else {
                                            handleTargetHit(target, reactMs)
                                        }
                                    }
                                    .testTag("game_target_${target.id}"),
                                contentAlignment = Alignment.Center
                            ) {
                                ArcadeTactileTarget(
                                    target = target,
                                    fractionRemaining = fractionRemaining,
                                    sizeDp = targetSizeDp
                                )
                            }
                        }

                        // -------------------------------------------------
                        // FLOATING FEEDBACK POPUPS (+100, +250, فخ! -150)
                        // -------------------------------------------------
                        feedbackList.forEach { fb ->
                            val age = (System.currentTimeMillis() - fb.id).coerceAtLeast(0L)
                            val progress = (age.toFloat() / 800f).coerceIn(0f, 1f)
                            val floatYOffset = -42.dp * progress
                            val alpha = 1f - (progress * progress)
                            val scale = 0.9f + (progress * 0.25f)

                            val fbX = (fb.xFraction * (arenaWidthPx - 140f)).coerceAtLeast(20f)
                            val fbY = (fb.yFraction * (arenaHeightPx - 180f)).coerceAtLeast(100f)

                            Box(
                                modifier = Modifier
                                    .offset { IntOffset(fbX.roundToInt(), fbY.roundToInt()) }
                                    .offset(y = floatYOffset)
                                    .scale(scale)
                                    .alpha(alpha)
                                    .shadow(6.dp, RoundedCornerShape(10.dp), spotColor = fb.color)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (fb.isPenalty) Color(0xFF7F1D1D).copy(alpha = 0.9f) else Color(0xFF140C30).copy(alpha = 0.9f)
                                    )
                                    .border(1.dp, fb.color.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = fb.text,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        fontSize = 13.sp,
                                        color = fb.color
                                    )
                                )
                            }
                        }
                    }
                }

                GameState.PAUSED -> {
                    ArcadePauseOverlay(
                        onResume = { gameState = GameState.PLAYING },
                        onRestart = { startNewGame() },
                        onQuit = onBack
                    )
                }

                GameState.RESULTS -> {
                    ArcadeGameOverScreen(
                        score = score,
                        bestScore = bestScore,
                        maxCombo = maxCombo,
                        onPlayAgain = { startNewGame() },
                        onBackToGames = onBack
                    )
                }

                GameState.INTRO -> {
                    // Direct to countdown for pure fast arcade entry
                    ArcadeCountdownOverlay(
                        onFinished = {
                            gameState = GameState.PLAYING
                            if (currentTargets.isEmpty()) {
                                spawnNextTarget()
                            }
                        }
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 1. UNIFIED ARCADE HUD (Score, Timer, Pause, Streak)
// -----------------------------------------------------------------------------

@Composable
fun ArcadeGameHud(
    score: Int,
    secondsRemaining: Int,
    combo: Int,
    onPause: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current

    // Animated score count
    val animatedScore by animateIntAsState(
        targetValue = score,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "hud_score"
    )

    // Score scale bump on change
    val scoreScale = remember { Animatable(1f) }
    LaunchedEffect(score) {
        if (score > 0) {
            scoreScale.animateTo(1.12f, tween(80))
            scoreScale.animateTo(1f, tween(120))
        }
    }

    // Timer format mm:ss
    val minutes = secondsRemaining / 60
    val secs = secondsRemaining % 60
    val timeFormatted = String.format(java.util.Locale.US, "%d:%02d", minutes, secs)

    // Last 5 seconds pulse
    val isCriticalTime = secondsRemaining in 1..5
    val infiniteTransition = rememberInfiniteTransition(label = "timer_pulse")
    val timerPulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isCriticalTime) 1.25f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "timer_scale"
    )

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // RIGHT (RTL Start): PAUSE BUTTON (Minimalist Icon Circle)
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Color(0xFF1B113F).copy(alpha = 0.7f))
                .border(1.dp, Color(0xFF3E2880).copy(alpha = 0.5f), CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onPause
                )
                .testTag("game_pause_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Pause,
                contentDescription = strings.pause,
                tint = Color(0xFFCBD5E1),
                modifier = Modifier.size(20.dp)
            )
        }

        // CENTER: SCORE (Clean Bold Typography + Small Label + Flame)
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.scale(scoreScale.value)
        ) {
            Text(
                text = strings.score,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF94A3B8)
                )
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = String.format(java.util.Locale.US, "%,d", animatedScore),
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Black,
                        fontFamily = NumericFontFamily,
                        fontSize = 26.sp,
                        color = Color.White
                    )
                )

                // Small Flame for active Streak
                if (combo >= 2) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(1.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFEA580C).copy(alpha = 0.25f))
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.LocalFireDepartment,
                            contentDescription = null,
                            tint = Color(0xFFF97316),
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "$combo",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color(0xFFFDBA74)
                            )
                        )
                    }
                }
            }
        }

        // LEFT (RTL End): TIME (Clean Typography + mm:ss)
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.scale(timerPulseScale)
        ) {
            Text(
                text = strings.time,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF94A3B8)
                )
            )
            Text(
                text = timeFormatted,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = NumericFontFamily,
                    fontSize = 20.sp,
                    color = if (isCriticalTime) LumoCoral else Color.White
                )
            )
        }
    }
}

// -----------------------------------------------------------------------------
// 2. TACTILE GAME OBJECTS (Standard, Golden, Trap)
// -----------------------------------------------------------------------------

@Composable
fun ArcadeTactileTarget(
    target: QuickTarget,
    fractionRemaining: Float,
    sizeDp: androidx.compose.ui.unit.Dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "target_anim")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "target_pulse"
    )

    Box(
        modifier = Modifier
            .size(sizeDp)
            .scale(if (target.isGolden) pulseScale else 1f),
        contentAlignment = Alignment.Center
    ) {
        when {
            target.isTrap -> {
                // HAZARD TRAP (Crimson Octagon with Danger Cross & Warning Border)
                TactileTrapObject(
                    fractionRemaining = fractionRemaining,
                    sizeDp = sizeDp
                )
            }
            target.isGolden -> {
                // GOLDEN TARGET (24K Gold Radiant Disc with Star Emblem)
                TactileGoldenObject(
                    fractionRemaining = fractionRemaining,
                    sizeDp = sizeDp
                )
            }
            else -> {
                // STANDARD TARGET (Brand #1800AD Indigo Disc with Bolt Emblem)
                TactileStandardObject(
                    fractionRemaining = fractionRemaining,
                    sizeDp = sizeDp
                )
            }
        }
    }
}

@Composable
fun TactileStandardObject(
    fractionRemaining: Float,
    sizeDp: androidx.compose.ui.unit.Dp
) {
    val isExpiringSoon = fractionRemaining < 0.28f
    val ringColor = if (isExpiringSoon) LumoCoral else Color(0xFF6366F1)

    // Outer Shrinking Countdown Ring
    Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidth = 3.5.dp.toPx()
        val radius = (size.minDimension / 2f) - strokeWidth

        // Base Track
        drawCircle(
            color = Color(0xFF6366F1).copy(alpha = 0.15f),
            radius = radius,
            style = Stroke(width = strokeWidth)
        )

        // Countdown Arc
        drawArc(
            color = ringColor,
            startAngle = -90f,
            sweepAngle = 360f * fractionRemaining,
            useCenter = false,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )
    }

    // Inner Tactile Disc
    Surface(
        modifier = Modifier
            .size(sizeDp * 0.74f)
            .shadow(10.dp, CircleShape, spotColor = Color(0xFF1800AD)),
        shape = CircleShape,
        color = Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.radialGradient(
                        listOf(Color(0xFF4F46E5), Color(0xFF1800AD), Color(0xFF0F044A))
                    )
                )
                .border(1.5.dp, Color(0xFF818CF8).copy(alpha = 0.6f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Bolt,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun TactileGoldenObject(
    fractionRemaining: Float,
    sizeDp: androidx.compose.ui.unit.Dp
) {
    // Outer Golden Radiant Ring
    Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidth = 4.dp.toPx()
        val radius = (size.minDimension / 2f) - strokeWidth

        drawCircle(
            color = LumoAmber.copy(alpha = 0.2f),
            radius = radius,
            style = Stroke(width = strokeWidth)
        )

        drawArc(
            brush = Brush.sweepGradient(listOf(LumoAmber, Color(0xFFFDE047), LumoAmber)),
            startAngle = -90f,
            sweepAngle = 360f * fractionRemaining,
            useCenter = false,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )
    }

    // Gold Medallion Disc
    Surface(
        modifier = Modifier
            .size(sizeDp * 0.76f)
            .shadow(14.dp, CircleShape, spotColor = LumoAmber),
        shape = CircleShape,
        color = Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.radialGradient(
                        listOf(Color(0xFFFEF08A), LumoAmber, Color(0xFFB45309))
                    )
                )
                .border(2.dp, Color(0xFFFFFBEB), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Star,
                contentDescription = null,
                tint = Color(0xFF78350F),
                modifier = Modifier.size(26.dp)
            )
        }
    }
}

@Composable
fun TactileTrapObject(
    fractionRemaining: Float,
    sizeDp: androidx.compose.ui.unit.Dp
) {
    // Outer Danger Crimson Ring
    Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidth = 3.5.dp.toPx()
        val radius = (size.minDimension / 2f) - strokeWidth

        drawCircle(
            color = Color(0xFFDC2626).copy(alpha = 0.2f),
            radius = radius,
            style = Stroke(width = strokeWidth)
        )

        drawArc(
            color = Color(0xFFEF4444),
            startAngle = -90f,
            sweepAngle = 360f * fractionRemaining,
            useCenter = false,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )
    }

    // Hazard Shield Shape
    Surface(
        modifier = Modifier
            .size(sizeDp * 0.74f)
            .shadow(12.dp, RoundedCornerShape(14.dp), spotColor = Color(0xFFDC2626)),
        shape = RoundedCornerShape(14.dp),
        color = Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.radialGradient(
                        listOf(Color(0xFF991B1B), Color(0xFF450A0A), Color(0xFF1C0A0A))
                    )
                )
                .border(2.dp, Color(0xFFF87171), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            // Diagonal hazard lines
            Canvas(modifier = Modifier.fillMaxSize()) {
                val step = 10.dp.toPx()
                for (i in -4..8) {
                    drawLine(
                        color = Color(0xFFDC2626).copy(alpha = 0.35f),
                        start = Offset(i * step, 0f),
                        end = Offset(i * step + size.height, size.height),
                        strokeWidth = 2.5.dp.toPx()
                    )
                }
            }

            Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = null,
                tint = Color(0xFFFEF2F2),
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

// -----------------------------------------------------------------------------
// 3. COUNTDOWN (3, 2, 1, ابدأ) - Clean Large Typography, Fast Scale + Fade
// -----------------------------------------------------------------------------

@Composable
fun ArcadeCountdownOverlay(
    onFinished: () -> Unit
) {
    val strings = LocalStrings.current
    val soundManager = LocalSoundManager.current
    var countStep by remember { mutableIntStateOf(3) }
    val scale = remember { Animatable(0.4f) }
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        for (i in 3 downTo 1) {
            countStep = i
            soundManager.playTap()
            scale.snapTo(0.4f)
            alpha.snapTo(0f)
            launch { alpha.animateTo(1f, tween(100)) }
            scale.animateTo(1.2f, spring(dampingRatio = Spring.DampingRatioMediumBouncy))
            delay(220)
            launch { alpha.animateTo(0f, tween(100)) }
            delay(100)
        }

        // Final "ابدأ"
        countStep = 0
        soundManager.playLevelUp()
        scale.snapTo(0.5f)
        alpha.snapTo(0f)
        launch { alpha.animateTo(1f, tween(100)) }
        scale.animateTo(1.3f, spring(dampingRatio = Spring.DampingRatioMediumBouncy))
        delay(350)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070314).copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center
    ) {
        val countText = if (countStep > 0) "$countStep" else strings.go
        val textColor = if (countStep > 0) Color.White else LumoAmber

        Text(
            text = countText,
            style = MaterialTheme.typography.displayLarge.copy(
                fontWeight = FontWeight.Black,
                fontFamily = NumericFontFamily,
                fontSize = if (countStep > 0) 84.sp else 64.sp,
                color = textColor,
                textAlign = TextAlign.Center
            ),
            modifier = Modifier
                .scale(scale.value)
                .alpha(alpha.value)
        )
    }
}

// -----------------------------------------------------------------------------
// 4. GAME OVER SCREEN (Fast, Clean, Arcade Result, #1800AD Primary CTA)
// -----------------------------------------------------------------------------

@Composable
fun ArcadeGameOverScreen(
    score: Int,
    bestScore: Int,
    maxCombo: Int,
    onPlayAgain: () -> Unit,
    onBackToGames: () -> Unit
) {
    val strings = LocalStrings.current
    val isNewBest = score > bestScore && score > 0
    val displayBest = maxOf(score, bestScore)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF09041A).copy(alpha = 0.96f))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 400.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Header Label: انتهى الوقت
            Text(
                text = strings.gameOver,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8),
                    fontSize = 18.sp
                )
            )

            // Giant Score Number
            Text(
                text = String.format(java.util.Locale.US, "%,d", score),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontWeight = FontWeight.Black,
                    fontFamily = NumericFontFamily,
                    fontSize = 54.sp,
                    color = Color.White
                )
            )

            // Sub Metrics: أفضل نتيجة + السلسلة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Best Score
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (isNewBest) strings.newBestScore else strings.bestScore,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Medium,
                            color = if (isNewBest) LumoAmber else Color(0xFF94A3B8),
                            fontSize = 12.sp
                        )
                    )
                    Text(
                        text = String.format(java.util.Locale.US, "%,d", displayBest),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = NumericFontFamily,
                            fontSize = 17.sp,
                            color = Color(0xFFE2E8F0)
                        )
                    )
                }

                if (maxCombo >= 2) {
                    Spacer(modifier = Modifier.width(32.dp))

                    // Best Streak
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "أعلى سلسلة",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp
                            )
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.LocalFireDepartment,
                                contentDescription = null,
                                tint = Color(0xFFF97316),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "$maxCombo",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = NumericFontFamily,
                                    fontSize = 17.sp,
                                    color = Color(0xFFFDBA74)
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // PRIMARY BUTTON: [ العب مرة أخرى ] (Brand #1800AD / White Text, NOT RED!)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1800AD))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onPlayAgain
                    )
                    .testTag("game_over_play_again"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = strings.playAgain,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 16.sp
                        )
                    )
                }
            }

            // SECONDARY BUTTON: [ العودة للألعاب ] (Clean subtle button)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1B113F).copy(alpha = 0.6f))
                    .border(1.dp, Color(0xFF382379).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onBackToGames
                    )
                    .testTag("game_over_back_to_games"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = strings.backToGames,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFCBD5E1),
                        fontSize = 15.sp
                    )
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 5. PAUSE OVERLAY (Minimal, Centered)
// -----------------------------------------------------------------------------

@Composable
fun ArcadePauseOverlay(
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onQuit: () -> Unit
) {
    val strings = LocalStrings.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070314).copy(alpha = 0.88f))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 340.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Pause Icon & Title
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1800AD).copy(alpha = 0.35f))
                    .border(1.5.dp, Color(0xFF6366F1).copy(alpha = 0.4f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Pause,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            Text(
                text = strings.pause,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 20.sp
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Resume CTA
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF1800AD))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onResume
                    )
                    .testTag("pause_resume_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = strings.resume,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    )
                }
            }

            // Restart Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF1C1242).copy(alpha = 0.8f))
                    .border(1.dp, Color(0xFF3B277A).copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onRestart
                    )
                    .testTag("pause_restart_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = strings.restart,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFCBD5E1),
                        fontSize = 14.sp
                    )
                )
            }

            // Quit Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Transparent)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onQuit
                    )
                    .testTag("pause_quit_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = strings.quit,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF94A3B8),
                        fontSize = 14.sp
                    )
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 6. AMBIENT PARTICLES (Subtle, non-distracting arcade canvas)
// -----------------------------------------------------------------------------

@Composable
fun AmbientArcadeCanvas() {
    val infiniteTransition = rememberInfiniteTransition(label = "ambient_anim")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ambient_phase"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Subtle geometric guide crosshair
        drawLine(
            color = Color(0xFF1E134D).copy(alpha = 0.35f),
            start = Offset(w / 2f, 80.dp.toPx()),
            end = Offset(w / 2f, h - 80.dp.toPx()),
            strokeWidth = 1.dp.toPx()
        )
        drawLine(
            color = Color(0xFF1E134D).copy(alpha = 0.35f),
            start = Offset(40.dp.toPx(), h / 2f),
            end = Offset(w - 40.dp.toPx(), h / 2f),
            strokeWidth = 1.dp.toPx()
        )

        // Center Subtle Reticle Circle
        drawCircle(
            color = Color(0xFF6366F1).copy(alpha = 0.08f),
            radius = 60.dp.toPx(),
            center = Offset(w / 2f, h / 2f),
            style = Stroke(width = 1.5.dp.toPx())
        )

        // Tiny floating spark particles
        val particles = listOf(
            Triple(0.2f, 0.3f, 2.5.dp.toPx()),
            Triple(0.8f, 0.25f, 3.0.dp.toPx()),
            Triple(0.15f, 0.7f, 2.0.dp.toPx()),
            Triple(0.85f, 0.75f, 3.5.dp.toPx()),
            Triple(0.5f, 0.85f, 2.2.dp.toPx())
        )

        particles.forEachIndexed { index, (fx, fy, radius) ->
            val yOffset = sin((phase + index * 0.2f) * 2 * Math.PI.toFloat()) * 15f
            drawCircle(
                color = Color(0xFF818CF8).copy(alpha = 0.20f),
                radius = radius,
                center = Offset(fx * w, fy * h + yOffset)
            )
        }
    }
}
